# Bubble Media Widget

A functional Android home-screen widget built from your glass/bubble media-player
design. It shows **whatever is actually playing on the device** (Spotify, YouTube
Music, the phone's own player, etc.) and lets you control it — play/pause, skip,
previous, shuffle, and favorite (where the source app supports it).

## Why it doesn't hardcode "Blinding Lights"

Your mockup uses The Weeknd's actual album art/track as a placeholder. A real
widget can't ship someone else's copyrighted artwork baked into the APK — and
it doesn't need to. Instead, at runtime the widget reads the album art bitmap,
title, and artist straight out of the currently active `MediaSession` (the
same system API Spotify/YT Music widgets use to expose "now playing" data).
So the widget will correctly show whatever song is actually playing, art and
all, for any app.

## How it works

- **`MediaNotificationListener`** — a `NotificationListenerService` that asks
  Android for the current active media session(s). This requires the user to
  grant **Settings → Apps → Special access → Notification access** once (there's
  no way around this on modern Android; it's the same permission every
  now-playing widget needs).
- **`MediaSessionHolder`** — holds the current `MediaController` and exposes
  `playPause()`, `skipNext()`, `skipPrevious()`, `toggleShuffle()`, etc.
- **`WidgetUpdater`** — builds the `RemoteViews` (text, album art, progress bar,
  button icons) and wires each button to a `PendingIntent`.
- **`BubbleMediaWidgetProvider`** — the `AppWidgetProvider` Android calls on
  widget placement/update, and that receives the button-tap broadcasts.

## The wave animation

- **`WaveGenerator`** draws one frame: layered translucent "hill" shapes using
  colors pulled from the current album art (via `PaletteExtractor`, using
  AndroidX Palette).
- **`WaveEngine`** is the animation loop — it eases an amplitude value toward
  1 (playing) or 0 (paused) every ~120ms, feeding the current amplitude/phase
  into `WaveGenerator`. As amplitude shrinks toward 0 on pause, the wave's
  resting line also sinks toward the seek bar, which is what gives the
  "settles and falls into the player" feel.
- **`WaveAnimationService`** is a foreground service that keeps this loop
  alive. Android kills background loops within minutes otherwise — this is
  the same mechanism any music app's own playback notification relies on. It
  shows a minimum-priority, silent notification only while something is
  playing or the wave is settling, and stops itself automatically once the
  wave goes flat.
- **`BackgroundArtProcessor`** turns the raw album art into the panel's
  background: crop to the widget's aspect ratio, shrink-then-upscale for a
  cheap blur (real blur APIs aren't available inside a widget), then darken
  with a scrim so text stays legible over any artwork.

### Honest tradeoffs

- **The wave is decorative, not audio-reactive.** Android doesn't expose the
  actual audio waveform of another app's playback to a widget — there's no
  API for that. The animation is a smooth, colorful motion synced to
  play/pause state, not to the music itself.
- **Battery/IPC cost.** Pushing a new bitmap to the widget ~8x/second while
  something plays is more expensive than a static widget. This implementation
  reuses a cached `RemoteViews` object per widget instance to keep it as cheap
  as possible, but it's still real, ongoing work — worth watching in a
  battery profiler on real devices, and worth reducing `FRAME_INTERVAL_MS` in
  `WaveEngine` if you want to trade smoothness for battery life. On API 31+,
  swapping `AppWidgetManager.updateAppWidget` for
  `AppWidgetManager.partiallyUpdateAppWidget` in `updateWaveFrame` would cut
  this cost further.
- **Position/duration text won't tick every second.** It only refreshes when
  the media app fires a state/metadata change (play, pause, seek, track
  change) or a widget button is tapped — there's no separate per-second
  polling loop. Add one (a lightweight periodic update while `isPlaying`) if
  you want the numbers ticking live.
- **The persistent notification is visible**, same as any music app's. It's
  minimum priority and silent, but it will show in the notification shade
  whenever the wave is active.

## Visual notes / limitations

Native Android widgets (`RemoteViews`) can't do real-time blur or refraction,
so the "liquid glass" bubbles are approximated with layered radial-gradient
drawables (`bg_glass_bubble.xml`, `bg_glass_bubble_center.xml`) — good enough
for a solid look, but not pixel-identical to your render.

**To get it pixel-perfect:** export each button's glass bubble as a PNG/WebP
(normal + pressed state) from Figma/your design tool at the sizes you need
(e.g. `@drawable/btn_play_normal.png`), and swap them in for the vector
drawables in `widget_bubble_media_player.xml`. RemoteViews handles PNG
backgrounds fine; it just can't *generate* glass rendering on its own.

## Wiring this into your multi-widget app

Since this is one of several widgets you'll ship:

1. Keep each widget in its own package (e.g. `com.bubblewidgets.media`,
   `com.bubblewidgets.weather`, `com.bubblewidgets.clock`) so their
   providers/layouts/resources don't collide.
2. Each widget needs its own `<receiver>` entry in `AndroidManifest.xml` and
   its own `appwidget-provider` XML — but they can all share this single
   `MediaNotificationListener`/permission grant if more than one widget needs
   media data.
3. Consider a small in-app "widget gallery" `Activity` that lets users preview
   and pin each widget — that's what `previewImage` in the widget-info XML
   feeds into for the system picker, but an in-app gallery gives you more
   control over presentation.

## Setup

1. Open in Android Studio (Giraffe+), let Gradle sync.
2. Run on a device/emulator running Android 8.0+ (`minSdk 26`).
3. Long-press the home screen → Widgets → **Bubble Media Player** → drag to place.
4. Grant notification access when prompted (or the widget will just show
   "Nothing playing" until you do — it fails safe, no crash).
5. Play something in any music app; the widget updates automatically.

## File map

```
app/src/main/
├── AndroidManifest.xml
├── java/com/bubblewidgets/media/
│   ├── BubbleMediaWidgetProvider.kt   # AppWidgetProvider entry point
│   ├── MediaNotificationListener.kt   # discovers active media sessions
│   ├── MediaSessionHolder.kt          # holds controller + control calls
│   ├── WidgetUpdater.kt               # builds RemoteViews, binds buttons
│   ├── WaveEngine.kt                  # animation loop (amplitude/phase easing)
│   ├── WaveGenerator.kt               # draws one wave frame as a bitmap
│   ├── WaveAnimationService.kt        # foreground service hosting the loop
│   ├── PaletteExtractor.kt            # album art -> dominant colors
│   └── BackgroundArtProcessor.kt      # album art -> blurred/darkened background
├── res/drawable/                      # glass panel/bubbles, icons
├── res/layout/widget_bubble_media_player.xml
├── res/xml/bubble_media_widget_info.xml
└── res/values/{colors,strings}.xml
```
