package com.bubblewidgets.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Android won't let a plain background loop run indefinitely -- it gets
 * throttled or killed within minutes. Running as a foreground service (with
 * a minimal, low-priority notification, same category as any music app's
 * playback notification) is the supported way to keep the animation loop
 * alive for as long as something is actually playing.
 *
 * The service starts when playback starts, and stops itself automatically
 * once the settle animation finishes after a pause -- it does not run
 * indefinitely in the background.
 */
class WaveAnimationService : Service() {

    companion object {
        private const val CHANNEL_ID = "wave_animation_sync"
        private const val NOTIFICATION_ID = 42
        private const val ACTION_PLAY = "com.bubblewidgets.wave.PLAY"
        private const val ACTION_SETTLE = "com.bubblewidgets.wave.SETTLE"

        fun startPlaying(context: Context) {
            val intent = Intent(context, WaveAnimationService::class.java).setAction(ACTION_PLAY)
            context.startForegroundService(intent)
        }

        fun triggerSettle(context: Context) {
            val intent = Intent(context, WaveAnimationService::class.java).setAction(ACTION_SETTLE)
            context.startForegroundService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannelIfNeeded()
        startForeground(NOTIFICATION_ID, buildNotification())

        WaveEngine.onFrame = { bitmap -> WidgetUpdater.updateWaveFrame(applicationContext, bitmap) }
        WaveEngine.onIdle = { stopSelf() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> WaveEngine.play()
            ACTION_SETTLE -> WaveEngine.settle()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        WaveEngine.stopImmediately()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Widget animation sync",
                    NotificationManager.IMPORTANCE_MIN
                ).apply {
                    description = "Keeps the media widget's wave animation running while music plays"
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Widget animation active")
            .setContentText("Syncing the wave animation to your currently playing media")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
    }
}
