package com.bubblewidgets.media

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

/**
 * A separate, dedicated 4x1 widget -- its own entry in the widget picker,
 * distinct from the main resizable BubbleMediaWidgetProvider. Added because
 * that widget's resizable bucket system doesn't reliably offer a true
 * short/wide shape on every launcher's grid-snapping (some only expose
 * squarer sizes like 2x2/2x3/2x4/3x4/4x4). This one is fixed to the wide
 * layout and isn't meant to switch buckets at all.
 *
 * Behavior mirrors BubbleMediaWidgetProvider exactly -- same actions, same
 * media session, same wave animation -- it's only the layout and widget-info
 * (size/shape) that differ. See WidgetUpdater, which already knows to treat
 * this provider's instances as always-wide via its providerClass parameter.
 */
class BubbleMediaWidgetWideProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> WidgetUpdater.updateAppWidget(context, manager, id, BubbleMediaWidgetWideProvider::class.java) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        manager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        WidgetUpdater.updateAppWidget(context, manager, appWidgetId, BubbleMediaWidgetWideProvider::class.java)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent) // still lets AppWidgetProvider handle APPWIDGET_UPDATE etc.

        val appWidgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        )

        when (intent.action) {
            WidgetUpdater.ACTION_PLAY_PAUSE -> MediaSessionHolder.playPause()
            WidgetUpdater.ACTION_NEXT -> MediaSessionHolder.skipNext()
            WidgetUpdater.ACTION_PREV -> MediaSessionHolder.skipPrevious()
            WidgetUpdater.ACTION_SHUFFLE -> MediaSessionHolder.toggleShuffle()
            WidgetUpdater.ACTION_FAVORITE -> MediaSessionHolder.toggleFavoriteIfSupported()
            else -> return
        }

        if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            val manager = AppWidgetManager.getInstance(context)
            WidgetUpdater.updateAppWidget(context, manager, appWidgetId, BubbleMediaWidgetWideProvider::class.java)
        } else {
            WidgetUpdater.updateAllWidgets(context)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        appWidgetIds.forEach {
            WidgetUpdater.forgetWidget(it)
            WidgetOpenAppPrefs.clear(context, it)
        }
    }
}
