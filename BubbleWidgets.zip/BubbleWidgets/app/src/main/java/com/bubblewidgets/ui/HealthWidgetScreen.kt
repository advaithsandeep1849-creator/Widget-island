package com.bubblewidgets.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bubblewidgets.health.BubbleHealthWidgetProvider
import com.bubblewidgets.health.HealthDataProvider
import com.bubblewidgets.ui.theme.AccentHealth
import com.bubblewidgets.ui.theme.GlassFill
import com.bubblewidgets.ui.theme.GlassRim
import com.bubblewidgets.ui.theme.SpaceBlack
import com.bubblewidgets.ui.theme.SpaceIndigo
import com.bubblewidgets.ui.theme.SpaceNavy
import com.bubblewidgets.ui.theme.TextMuted
import com.bubblewidgets.ui.theme.TextPrimary
import com.bubblewidgets.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun HealthWidgetScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var permissionsGranted by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = HealthDataProvider.requestPermissionsContract()
    ) { granted ->
        permissionsGranted = granted.containsAll(HealthDataProvider.PERMISSIONS)
        statusMessage = if (permissionsGranted) {
            "Health access granted."
        } else {
            "Some permissions weren't granted -- the widget will show 0 for anything not allowed."
        }
    }

    LaunchedEffect(Unit) {
        permissionsGranted = HealthDataProvider.hasAllPermissions(context)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SpaceBlack, SpaceNavy, SpaceIndigo)))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp, bottom = 24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(GlassFill)
                        .border(1.dp, GlassRim, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Text(
                    "Health Widget",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp)
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(GlassFill, Color.Transparent)))
                    .border(1.dp, GlassRim, RoundedCornerShape(28.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    MiniRingsPreview()
                    Text(
                        "Steps, calories, active time, sleep",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                    Text(
                        "Reads live from Health Connect.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            Text(
                "Setup",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 20.dp, bottom = 10.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(GlassFill)
                    .border(1.dp, GlassRim, RoundedCornerShape(18.dp))
                    .clickable {
                        scope.launch {
                            val client = HealthDataProvider.getClientOrNull(context)
                            if (client == null) {
                                statusMessage = "Health Connect isn't installed on this device."
                            } else {
                                permissionLauncher.launch(HealthDataProvider.PERMISSIONS)
                            }
                        }
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.DirectionsRun, contentDescription = null, tint = AccentHealth)
                Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                    Text("Health Connect access", color = TextPrimary, fontSize = 15.sp)
                    Text(
                        if (permissionsGranted) "Granted" else "Not granted yet -- tap to allow",
                        color = if (permissionsGranted) AccentHealth else TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            Text(
                "Goals for each ring (10,000 steps, 500 calories, etc.) are coming here next.",
                color = TextMuted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 12.dp)
            )

            Box(modifier = Modifier.weight(1f))

            statusMessage?.let {
                Text(it, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 12.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(AccentHealth, com.bubblewidgets.ui.theme.WordmarkEnd)))
                    .clickable {
                        statusMessage = requestPinHealthWidget(context)
                    }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Add to Home Screen", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MiniRingsPreview() {
    val colors = listOf(
        Color(0xFFB07CFF) to 0.9f,
        Color(0xFFFFC44D) to 0.8f,
        Color(0xFF4CD97B) to 0.64f,
        Color(0xFF3BC9FF) to 0.62f,
    )
    Canvas(modifier = Modifier.size(120.dp)) {
        val strokeWidth = 10f
        val gap = 4f
        colors.forEachIndexed { index, (color, progress) ->
            val radius = size.minDimension / 2f - strokeWidth / 2f - index * (strokeWidth + gap)
            val topLeft = Offset(center.x - radius, center.y - radius)
            val arcSize = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
            drawArc(
                color = color.copy(alpha = 0.25f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
    }
}

private fun requestPinHealthWidget(context: Context): String {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        return "Pinning widgets from the app needs Android 8.0 or newer -- long-press your home screen instead."
    }
    val appWidgetManager = AppWidgetManager.getInstance(context)
    val provider = ComponentName(context, BubbleHealthWidgetProvider::class.java)
    return if (appWidgetManager.isRequestPinAppWidgetSupported) {
        appWidgetManager.requestPinAppWidget(provider, null, null)
        "Check your home screen to confirm placement."
    } else {
        "Your launcher doesn't support adding widgets this way -- long-press your home screen instead."
    }
}
