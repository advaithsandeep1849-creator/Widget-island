package com.bubblewidgets.health

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** The four metrics this widget shows, alongside today's goal for each. */
data class HealthSnapshot(
    val steps: Long,
    val stepsGoal: Long = 10_000,
    val activeCalories: Long,
    val caloriesGoal: Long = 500,
    val activeMinutes: Long,
    val activeMinutesGoal: Long = 60,
    val sleepMinutes: Long,
    val sleepGoalMinutes: Long = 8 * 60
)

/**
 * What state Health Connect is in on this device. There isn't just
 * "installed or not" -- it can also be present but need a Play Store update
 * before it'll actually work, which needs a different message/action than a
 * clean "not installed" state.
 */
enum class HealthConnectAvailability { AVAILABLE, NOT_INSTALLED, NEEDS_UPDATE }

object HealthDataProvider {

    private const val HEALTH_CONNECT_PACKAGE = "com.google.android.apps.healthdata"

    val PERMISSIONS = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
    )

    fun getAvailability(context: Context): HealthConnectAvailability {
        return when (HealthConnectClient.getSdkStatus(context, HEALTH_CONNECT_PACKAGE)) {
            HealthConnectClient.SDK_AVAILABLE -> HealthConnectAvailability.AVAILABLE
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> HealthConnectAvailability.NEEDS_UPDATE
            else -> HealthConnectAvailability.NOT_INSTALLED
        }
    }

    /** Null unless Health Connect is actually installed AND up to date. */
    fun getClientOrNull(context: Context): HealthConnectClient? =
        if (getAvailability(context) == HealthConnectAvailability.AVAILABLE) {
            HealthConnectClient.getOrCreate(context)
        } else {
            null
        }

    /**
     * Opens Health Connect's Play Store listing, for either a fresh install
     * or an update -- same destination either way, Play Store shows
     * "Install" or "Update" depending on what's already on the device.
     */
    fun installOrUpdateIntent(): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$HEALTH_CONNECT_PACKAGE"))

    suspend fun hasAllPermissions(context: Context): Boolean {
        val client = getClientOrNull(context) ?: return false
        val granted = client.permissionController.getGrantedPermissions()
        return granted.containsAll(PERMISSIONS)
    }

    fun requestPermissionsContract() = PermissionController.createRequestPermissionResultContract()

    /**
     * Reads today's totals. Any individual read that fails (a permission not
     * granted, no data for that type, etc.) just falls back to 0 for that
     * one metric rather than failing the whole snapshot -- a person who's
     * only granted steps access should still see their steps.
     */
    suspend fun readTodaySnapshot(context: Context): HealthSnapshot {
        val client = getClientOrNull(context)
            ?: return HealthSnapshot(steps = 0, activeCalories = 0, activeMinutes = 0, sleepMinutes = 0)

        val zone = ZoneId.systemDefault()
        val startOfDay = LocalDate.now(zone).atStartOfDay(zone).toInstant()
        val now = Instant.now()
        val todayRange = TimeRangeFilter.between(startOfDay, now)

        val steps = runCatching {
            client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), timeRangeFilter = todayRange))
                .get(StepsRecord.COUNT_TOTAL) ?: 0L
        }.getOrDefault(0L)

        val calories = runCatching {
            client.aggregate(
                AggregateRequest(setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), timeRangeFilter = todayRange)
            ).get(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL)?.inKilocalories?.toLong() ?: 0L
        }.getOrDefault(0L)

        val activeMinutes = runCatching {
            val sessions = client.readRecords(
                ReadRecordsRequest(ExerciseSessionRecord::class, timeRangeFilter = todayRange)
            ).records
            sessions.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
        }.getOrDefault(0L)

        // Sleep is read over the last ~20 hours rather than "since midnight" --
        // most sleep sessions start the previous evening, so a midnight cutoff
        // would miss most of a normal night's sleep entirely.
        val sleepMinutes = runCatching {
            val sleepRange = TimeRangeFilter.between(now.minus(Duration.ofHours(20)), now)
            val sessions = client.readRecords(
                ReadRecordsRequest(SleepSessionRecord::class, timeRangeFilter = sleepRange)
            ).records
            sessions.sumOf { Duration.between(it.startTime, it.endTime).toMinutes() }
        }.getOrDefault(0L)

        return HealthSnapshot(
            steps = steps,
            activeCalories = calories,
            activeMinutes = activeMinutes,
            sleepMinutes = sleepMinutes
        )
    }
}
