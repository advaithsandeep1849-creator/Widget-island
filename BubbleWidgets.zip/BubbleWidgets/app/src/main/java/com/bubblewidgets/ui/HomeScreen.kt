package com.bubblewidgets.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bubblewidgets.ui.theme.AccentAesthetic
import com.bubblewidgets.ui.theme.AccentClock
import com.bubblewidgets.ui.theme.AccentHealth
import com.bubblewidgets.ui.theme.AccentMedia
import com.bubblewidgets.ui.theme.AccentTools
import com.bubblewidgets.ui.theme.AccentWeather
import com.bubblewidgets.ui.theme.GlassFill
import com.bubblewidgets.ui.theme.GlassRim
import com.bubblewidgets.ui.theme.GlassSheen
import com.bubblewidgets.ui.theme.SpaceBlack
import com.bubblewidgets.ui.theme.SpaceIndigo
import com.bubblewidgets.ui.theme.SpaceNavy
import com.bubblewidgets.ui.theme.TextMuted
import com.bubblewidgets.ui.theme.TextPrimary
import com.bubblewidgets.ui.theme.TextSecondary
import com.bubblewidgets.ui.theme.WordmarkEnd
import com.bubblewidgets.ui.theme.WordmarkStart

data class WidgetCategory(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val available: Boolean
)

val widgetCategories = listOf(
    WidgetCategory("Media", "Your sound. Beautifully.", Icons.Filled.MusicNote, AccentMedia, available = true),
    WidgetCategory("Health", "A healthier you.", Icons.Filled.DirectionsRun, AccentHealth, available = true),
    WidgetCategory("Clock", "Timeless designs.", Icons.Filled.Schedule, AccentClock, available = false),
    WidgetCategory("Weather", "Live and beautiful.", Icons.Filled.WbSunny, AccentWeather, available = false),
    WidgetCategory("Tools", "Do more. Faster.", Icons.Filled.Build, AccentTools, available = false),
    WidgetCategory("Aesthetic", "Make it yours.", Icons.Filled.AutoAwesome, AccentAesthetic, available = false),
)

/**
 * The app's front door: a dark, cosmic backdrop (inspired by the reference
 * onboarding art) behind a scrollable list of widget-category cards in the
 * same frosted-glass material the widgets themselves use, tying the app's
 * own UI and the widgets it produces together visually. Only "Media" is
 * wired up to anything real right now -- the rest are marked "Coming soon"
 * since those widgets don't exist yet.
 */
@Composable
fun HomeScreen(onCategoryClick: (WidgetCategory) -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) {
        CosmicBackground()

        Column(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 56.dp, start = 24.dp, end = 24.dp, bottom = 8.dp)
            ) {
                Text(
                    text = "Bubble",
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Black,
                    style = androidx.compose.ui.text.TextStyle(
                        brush = Brush.linearGradient(listOf(WordmarkStart, WordmarkEnd))
                    )
                )
                Text(
                    text = "W I D G E T S",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    letterSpacing = 4.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Text(
                    text = "Small details. A bigger you.",
                    color = TextMuted,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(widgetCategories) { category ->
                    CategoryCard(category = category, onClick = { onCategoryClick(category) })
                }
            }

            BottomNavBar()
        }
    }
}

@Composable
private fun CosmicBackground() {
    // Soft drifting glow instead of a static gradient -- gives the
    // background a very subtle sense of life without being distracting.
    val transition = rememberInfiniteTransition(label = "cosmic_drift")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "drift"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SpaceBlack, SpaceNavy, SpaceIndigo)))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val glowCenter = Offset(size.width * (0.75f + drift * 0.15f), size.height * 0.12f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(WordmarkEnd.copy(alpha = 0.18f), Color.Transparent),
                    center = glowCenter,
                    radius = size.width * 0.65f
                ),
                radius = size.width * 0.65f,
                center = glowCenter
            )
            val glowCenter2 = Offset(size.width * (0.2f - drift * 0.1f), size.height * 0.85f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(AccentMedia.copy(alpha = 0.10f), Color.Transparent),
                    center = glowCenter2,
                    radius = size.width * 0.55f
                ),
                radius = size.width * 0.55f,
                center = glowCenter2
            )
        }
    }
}

@Composable
private fun CategoryCard(category: WidgetCategory, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.verticalGradient(listOf(GlassFill, Color.Transparent)))
            .border(1.dp, GlassRim, RoundedCornerShape(24.dp))
            .clickable(enabled = category.available, onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(category.accent.copy(alpha = 0.35f), category.accent.copy(alpha = 0.08f)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(category.icon, contentDescription = category.title, tint = category.accent)
        }

        Column(modifier = Modifier.padding(start = 16.dp).weight(1f)) {
            Text(category.title, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(category.subtitle, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }

        if (!category.available) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(GlassSheen)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text("Soon", color = TextMuted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun BottomNavBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .clip(RoundedCornerShape(50))
            .background(GlassFill)
            .border(1.dp, GlassRim, RoundedCornerShape(50))
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        NavItem("Home", Icons.Filled.Home, selected = true)
        NavItem("Explore", Icons.Outlined.Explore, selected = false)
        NavItem("Customize", Icons.Outlined.Edit, selected = false)
        NavItem("More", Icons.Outlined.MoreHoriz, selected = false)
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, selected: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = if (selected) WordmarkEnd else TextMuted)
        Text(
            label,
            color = if (selected) TextPrimary else TextMuted,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}
