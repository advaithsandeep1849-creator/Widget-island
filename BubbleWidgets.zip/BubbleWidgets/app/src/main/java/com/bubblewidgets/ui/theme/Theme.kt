package com.bubblewidgets.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val BubbleColorScheme = darkColorScheme(
    background = SpaceBlack,
    surface = SpaceNavy,
    primary = WordmarkEnd,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
)

@Composable
fun BubbleWidgetsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BubbleColorScheme,
        content = content
    )
}
