package com.bubblewidgets.media

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Required so we're allowed to call MediaSessionManager#getActiveSessions().
 * The user has to grant this once, in Settings > Notification access —
 * same permission Spotify/YT Music-style widgets rely on.
 */
class MediaNotificationListener : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null
    private val sessionsChangedListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            pickActiveController(controllers)
        }

    override fun onListenerConnected() {
        super.onListenerConnected()
        sessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val component = ComponentName(this, MediaNotificationListener::class.java)

        MediaSessionHolder.setOnChangedListener { WidgetUpdater.updateAllWidgets(applicationContext) }

        sessionManager?.addOnActiveSessionsChangedListener(sessionsChangedListener, component)
        pickActiveController(sessionManager?.getActiveSessions(component))
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        sessionManager?.removeOnActiveSessionsChangedListener(sessionsChangedListener)
        MediaSessionHolder.attach(null)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // A new/changed media notification usually means playback state changed
        // for the posting app; re-evaluate which session is "active".
        val component = ComponentName(this, MediaNotificationListener::class.java)
        pickActiveController(sessionManager?.getActiveSessions(component))
    }

    private fun pickActiveController(controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) {
            MediaSessionHolder.attach(null)
            WidgetUpdater.updateAllWidgets(applicationContext)
            return
        }
        // Prefer a session that's actually playing; otherwise take the first.
        val playing = controllers.firstOrNull {
            it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
        }
        MediaSessionHolder.attach(playing ?: controllers.first())
        WidgetUpdater.updateAllWidgets(applicationContext)
    }
}
