package com.bubblewidgets

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.bubblewidgets.ui.HomeScreen
import com.bubblewidgets.ui.MusicWidgetScreen
import com.bubblewidgets.ui.theme.BubbleWidgetsTheme

/**
 * The app's front door -- previously this project had no launchable activity
 * at all (it was widget-only). Navigation is a simple in-memory screen
 * switch rather than a full nav graph, since there are only two screens so
 * far; worth upgrading to Navigation-Compose once more widget screens exist.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BubbleWidgetsTheme {
                var showMusicScreen by remember { mutableStateOf(false) }
                if (showMusicScreen) {
                    MusicWidgetScreen(onBack = { showMusicScreen = false })
                } else {
                    HomeScreen(onCategoryClick = { category ->
                        if (category.title == "Media") showMusicScreen = true
                    })
                }
            }
        }
    }
}
