package com.bubblewidgets

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.bubblewidgets.ui.HealthWidgetScreen
import com.bubblewidgets.ui.HomeScreen
import com.bubblewidgets.ui.MusicWidgetScreen
import com.bubblewidgets.ui.theme.BubbleWidgetsTheme

/**
 * The app's front door -- previously this project had no launchable activity
 * at all (it was widget-only). Navigation is a simple in-memory screen
 * switch rather than a full nav graph, since there are only a few screens so
 * far; worth upgrading to Navigation-Compose once more widget screens exist.
 */
private enum class Screen { HOME, MUSIC, HEALTH }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BubbleWidgetsTheme {
                var screen by remember { mutableStateOf(Screen.HOME) }
                when (screen) {
                    Screen.MUSIC -> MusicWidgetScreen(onBack = { screen = Screen.HOME })
                    Screen.HEALTH -> HealthWidgetScreen(onBack = { screen = Screen.HOME })
                    Screen.HOME -> HomeScreen(onCategoryClick = { category ->
                        screen = when (category.title) {
                            "Media" -> Screen.MUSIC
                            "Health" -> Screen.HEALTH
                            else -> Screen.HOME
                        }
                    })
                }
            }
        }
    }
}
