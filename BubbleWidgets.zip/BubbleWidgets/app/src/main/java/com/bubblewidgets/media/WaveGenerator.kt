package com.bubblewidgets.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.sin

/**
 * Draws layered, translucent, colorful "hill" shapes that overlap to look like
 * the wavy visualization in the reference design. Each call produces one frame;
 * [WaveEngine] calls this repeatedly with an advancing [phase] to animate it,
 * and shrinks [amplitude] toward 0 to make the wave settle and flatten.
 */
object WaveGenerator {

    val DEFAULT_COLORS = intArrayOf(
        0xFFFF3B5C.toInt(), // pink/red
        0xFFFF7A3B.toInt(), // orange
        0xFFB03BFF.toInt(), // purple
        0xFF3BB0FF.toInt()  // blue
    )

    /**
     * @param amplitude 0f (flat / settled) .. 1f (full height, actively "playing")
     * @param progressFraction 0f..1f playback position. The wave is drawn at
     * full color/energy only up to this point (matching the progress dot),
     * and as a flat, dim line beyond it -- representing what hasn't played
     * yet -- so the "active" wave visibly advances together with playback.
     * @param reuse an existing bitmap of the right size to draw into instead
     * of allocating a new one, to avoid per-frame GC churn.
     */
    fun generate(
        width: Int,
        height: Int,
        colors: IntArray,
        phase: Float,
        amplitude: Float,
        progressFraction: Float = 1f,
        reuse: Bitmap? = null
    ): Bitmap {
        val bmp = if (reuse != null && reuse.width == width && reuse.height == height && !reuse.isRecycled) {
            reuse
        } else {
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        }
        val canvas = Canvas(bmp)
        canvas.drawColor(0, android.graphics.PorterDuff.Mode.CLEAR)
        val palette = if (colors.isNotEmpty()) colors else DEFAULT_COLORS
        val playedX = (width * progressFraction.coerceIn(0f, 1f))

        // As amplitude shrinks toward 0, the wave's resting line sinks further
        // down toward the bottom edge -- this is what gives the "falling into
        // the player" feel when playback pauses.
        val baselineFraction = 0.55f + (1f - amplitude) * 0.4f
        val baseline = height * baselineFraction
        val maxPeakHeight = height * 0.55f * amplitude

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val step = (width / 80).coerceAtLeast(2)

        // A slow, gentle overall brightness pulse -- distinct from the wave's
        // shape motion -- so the colors themselves feel like they're softly
        // breathing/flowing rather than just the outline moving.
        val shimmer = 0.82f + 0.18f * ((sin(phase * 0.4f) + 1f) / 2f)

        for (i in palette.indices) {
            val frequency = 1.3f + i * 0.55f
            val layerPhase = phase + i * 1.8f
            val layerPeak = maxPeakHeight * (1f - i * 0.15f).coerceAtLeast(0.35f)

            val path = Path()
            path.moveTo(0f, height.toFloat())
            path.lineTo(0f, baseline)
            var x = 0
            while (x <= width) {
                val t = x / width.toFloat()
                val y = baseline - (sin(t * frequency * 2 * PI + layerPhase) * layerPeak).toFloat()
                path.lineTo(x.toFloat(), y)
                x += step
            }
            path.lineTo(width.toFloat(), baseline)
            path.lineTo(width.toFloat(), height.toFloat())
            path.close()

            // Vivid, full color only up to the played position -- nothing is
            // drawn beyond it. The wave should read as "how far we've
            // gotten," ending right at the progress dot, not continuing on
            // as an ambient decoration past what's actually played.
            paint.color = palette[i]
            paint.alpha = (210 * shimmer).toInt().coerceIn(0, 255)
            canvas.save()
            canvas.clipRect(0f, 0f, playedX, height.toFloat())
            canvas.drawPath(path, paint)
            canvas.restore()
        }

        // Position marker: a small vertical rounded "pill" (matching a
        // typical player's scrub handle) rather than a ball -- solid,
        // always visible regardless of play/pause state.
        val dotY = height * 0.92f
        val pillWidth = 6f
        val pillHeight = 20f
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        // soft outer glow behind it
        dotPaint.color = 0x2EFFFFFF
        canvas.drawRoundRect(
            RectF(playedX - pillWidth, dotY - pillHeight * 0.7f, playedX + pillWidth, dotY + pillHeight * 0.7f),
            pillWidth, pillWidth, dotPaint
        )
        // solid pill body
        dotPaint.color = 0xFFF7F7F7.toInt()
        val pillRect = RectF(
            playedX - pillWidth / 2f, dotY - pillHeight / 2f,
            playedX + pillWidth / 2f, dotY + pillHeight / 2f
        )
        canvas.drawRoundRect(pillRect, pillWidth / 2f, pillWidth / 2f, dotPaint)

        return bmp
    }
}
