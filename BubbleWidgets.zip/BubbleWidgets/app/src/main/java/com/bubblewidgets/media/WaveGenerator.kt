package com.bubblewidgets.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.PI
import kotlin.math.sin

/**
 * Draws layered, translucent, colorful "hill" shapes that overlap to look like
 * the wavy visualization in the reference design. Each call produces one frame;
 * [WaveEngine] calls this repeatedly with an advancing [phase] to animate it,
 * and shrinks [amplitude] toward 0 to make the wave settle and flatten.
 */
object WaveGenerator {

    val DEFAULT_COLORS = intArrayOf(
        0xFFFF3B5C.toInt(), // pink/red
        0xFFFF7A3B.toInt(), // orange
        0xFFB03BFF.toInt(), // purple
        0xFF3BB0FF.toInt()  // blue
    )

    /**
     * @param amplitude 0f (flat / settled) .. 1f (full height, actively "playing")
     */
    fun generate(width: Int, height: Int, colors: IntArray, phase: Float, amplitude: Float): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val palette = if (colors.isNotEmpty()) colors else DEFAULT_COLORS

        // As amplitude shrinks toward 0, the wave's resting line sinks further
        // down toward the bottom edge -- this is what gives the "falling into
        // the player" feel when playback pauses.
        val baselineFraction = 0.55f + (1f - amplitude) * 0.4f
        val baseline = height * baselineFraction
        val maxPeakHeight = height * 0.55f * amplitude

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val step = (width / 80).coerceAtLeast(2)

        for (i in palette.indices) {
            paint.color = palette[i]
            paint.alpha = 110
            val frequency = 1.3f + i * 0.55f
            val layerPhase = phase + i * 1.8f
            val layerPeak = maxPeakHeight * (1f - i * 0.15f).coerceAtLeast(0.35f)

            val path = Path()
            path.moveTo(0f, height.toFloat())
            path.lineTo(0f, baseline)
            var x = 0
            while (x <= width) {
                val t = x / width.toFloat()
                val y = baseline - (sin(t * frequency * 2 * PI + layerPhase) * layerPeak).toFloat()
                path.lineTo(x.toFloat(), y)
                x += step
            }
            path.lineTo(width.toFloat(), baseline)
            path.lineTo(width.toFloat(), height.toFloat())
            path.close()

            canvas.drawPath(path, paint)
        }

        return bmp
    }
}
