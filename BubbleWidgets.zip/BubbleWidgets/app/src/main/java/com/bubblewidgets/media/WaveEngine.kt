package com.bubblewidgets.media

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper

/**
 * Drives the wave animation frame-by-frame. This is deliberately *not* tied
 * to real audio amplitude (Android gives widgets no access to the actual
 * audio signal of another app) -- it's a decorative animation whose target
 * height flips between "full" (playing) and "flat" (paused), eased smoothly
 * so pausing reads as the wave running out of energy and settling down
 * rather than an abrupt cut.
 */
object WaveEngine {

    private const val FRAME_INTERVAL_MS = 120L // ~8fps: smooth enough, battery-friendly
    private const val FRAME_WIDTH = 640
    private const val FRAME_HEIGHT = 160

    private var handler: Handler? = null
    private var running = false

    private var phase = 0f
    private var amplitude = 0f
    private var targetAmplitude = 0f

    private var colors: IntArray = WaveGenerator.DEFAULT_COLORS

    /** Called by [WaveAnimationService] to receive each generated frame. */
    var onFrame: ((Bitmap) -> Unit)? = null

    /** Called once the wave has fully settled after a pause, so the service can stop itself. */
    var onIdle: (() -> Unit)? = null

    fun setPaletteColors(newColors: IntArray) {
        if (newColors.isNotEmpty()) colors = newColors
    }

    /** Start (or resume) the moving wave. Safe to call repeatedly. */
    fun play() {
        if (targetAmplitude == 1f && running) return
        targetAmplitude = 1f
        ensureLoopRunning()
    }

    /** Begin damping the wave down to a flat line. The loop keeps running until it settles. */
    fun settle() {
        if (targetAmplitude == 0f) return
        targetAmplitude = 0f
        ensureLoopRunning()
    }

    fun stopImmediately() {
        running = false
        handler?.removeCallbacksAndMessages(null)
        handler = null
        amplitude = 0f
        phase = 0f
    }

    private fun ensureLoopRunning() {
        if (running) return
        running = true
        if (handler == null) handler = Handler(Looper.getMainLooper())
        scheduleNext()
    }

    private fun scheduleNext() {
        handler?.postDelayed({
            tick()
            if (running) scheduleNext()
        }, FRAME_INTERVAL_MS)
    }

    private fun tick() {
        // Ease amplitude toward its target -- this is what makes both the
        // ramp-up on play and the damping-down on pause feel smooth rather
        // than instant.
        amplitude += (targetAmplitude - amplitude) * 0.15f
        // The wave's forward motion also slows as it loses amplitude, like
        // it's running out of momentum, rather than moving at a constant
        // speed right up until it stops.
        phase += 0.12f + amplitude * 0.18f

        val frame = WaveGenerator.generate(FRAME_WIDTH, FRAME_HEIGHT, colors, phase, amplitude)
        onFrame?.invoke(frame)

        if (targetAmplitude == 0f && amplitude < 0.015f) {
            amplitude = 0f
            running = false
            handler?.removeCallbacksAndMessages(null)
            onIdle?.invoke()
        }
    }
}
