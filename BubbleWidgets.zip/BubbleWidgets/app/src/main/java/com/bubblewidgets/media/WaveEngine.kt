package com.bubblewidgets.media

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper

/**
 * Drives the wave animation frame-by-frame. This is deliberately *not* tied
 * to real audio amplitude (Android gives widgets no access to the actual
 * audio signal of another app) -- it's a decorative animation whose target
 * height flips between "full" (playing) and "flat" (paused), eased smoothly
 * so pausing reads as the wave running out of energy and settling down
 * rather than an abrupt cut.
 */
object WaveEngine {

    // Bumped up further based on a reference video showing how buttery-smooth
    // a native OS media slider looks -- widgets can't hit that frame rate,
    // but this is the highest we can push while keeping IPC payload sane.
    private const val FRAME_INTERVAL_MS = 70L // ~14fps
    // Every frame is parceled across processes to the launcher via
    // partiallyUpdateAppWidget. Kept small so the higher frequency above
    // doesn't add up to more total IPC traffic -- the wave is a soft, blurry
    // shape anyway, so a smaller source bitmap (stretched via fitXY) looks
    // effectively identical while keeping payload low.
    private const val FRAME_WIDTH = 240
    private const val FRAME_HEIGHT = 68

    private var handler: Handler? = null
    private var running = false

    private var phase = 0f
    private var amplitude = 0f
    private var targetAmplitude = 0f

    private var colors: IntArray = WaveGenerator.DEFAULT_COLORS

    // Reused across frames instead of allocating a new bitmap ~10x/sec, which
    // was causing enough GC churn to make the animation feel choppy.
    private var frameBitmap: Bitmap? = null

    // Drives frame timing off actual elapsed time rather than a fixed
    // postDelayed step, so drift/hiccups from a slow frame don't compound
    // into a visibly uneven, speeding-up-then-stalling motion.
    private var lastTickAtMs = 0L

    /** Called by [WaveAnimationService] to receive each generated frame. */
    var onFrame: ((Bitmap) -> Unit)? = null

    /** Called once the wave has fully settled after a pause, so the service can stop itself. */
    var onIdle: (() -> Unit)? = null

    fun setPaletteColors(newColors: IntArray) {
        if (newColors.isNotEmpty()) colors = newColors
    }

    /** Start (or resume) the moving wave. Safe to call repeatedly. */
    fun play() {
        if (targetAmplitude == 1f && running) return
        targetAmplitude = 1f
        ensureLoopRunning()
    }

    /** Begin damping the wave down to a flat line. The loop keeps running until it settles. */
    fun settle() {
        if (targetAmplitude == 0f) return
        targetAmplitude = 0f
        ensureLoopRunning()
    }

    fun stopImmediately() {
        running = false
        handler?.removeCallbacksAndMessages(null)
        handler = null
        amplitude = 0f
        phase = 0f
        frameBitmap = null
    }

    private fun ensureLoopRunning() {
        if (running) return
        running = true
        if (handler == null) handler = Handler(Looper.getMainLooper())
        lastTickAtMs = android.os.SystemClock.elapsedRealtime()
        scheduleNext()
    }

    private fun scheduleNext() {
        handler?.postDelayed({
            tick()
            if (running) scheduleNext()
        }, FRAME_INTERVAL_MS)
    }

    private fun tick() {
        val now = android.os.SystemClock.elapsedRealtime()
        // Scale motion by how much time actually passed (normalized to the
        // intended interval) instead of assuming exactly FRAME_INTERVAL_MS
        // always elapsed -- keeps speed consistent even if a frame is late.
        val deltaFactor = ((now - lastTickAtMs).toFloat() / FRAME_INTERVAL_MS).coerceIn(0.6f, 1.6f)
        lastTickAtMs = now

        // Ease amplitude toward its target. Pushed noticeably faster again --
        // pausing should read as a quick, smooth wind-down (still a curve,
        // not a hard cut), not a multi-second fade.
        amplitude += (targetAmplitude - amplitude) * 0.18f * deltaFactor
        // Faster, livelier drift -- still smooth, but closer to a normal
        // real-time pace instead of the very slow calming drift from before.
        phase += (0.06f + amplitude * 0.06f) * deltaFactor

        val durationMs = MediaSessionHolder.controller?.metadata
            ?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val progressFraction = if (durationMs > 0) {
            (MediaSessionHolder.estimatedPositionMs().toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else 1f

        val frame = WaveGenerator.generate(
            FRAME_WIDTH, FRAME_HEIGHT, colors, phase, amplitude, progressFraction, reuse = frameBitmap
        )
        frameBitmap = frame
        onFrame?.invoke(frame)

        if (targetAmplitude == 0f && amplitude < 0.015f) {
            amplitude = 0f
            running = false
            handler?.removeCallbacksAndMessages(null)
            onIdle?.invoke()
        }
    }
}
