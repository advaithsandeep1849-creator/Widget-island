package com.bubblewidgets.media

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

class BubbleMediaWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> WidgetUpdater.updateAppWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent) // still lets AppWidgetProvider handle APPWIDGET_UPDATE etc.

        val appWidgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        )

        when (intent.action) {
            WidgetUpdater.ACTION_PLAY_PAUSE -> MediaSessionHolder.playPause()
            WidgetUpdater.ACTION_NEXT -> MediaSessionHolder.skipNext()
            WidgetUpdater.ACTION_PREV -> MediaSessionHolder.skipPrevious()
            WidgetUpdater.ACTION_SHUFFLE -> MediaSessionHolder.toggleShuffle()
            WidgetUpdater.ACTION_FAVORITE -> MediaSessionHolder.toggleFavoriteIfSupported()
            else -> return
        }

        // Give the media app a brief moment to reflect the new state, then refresh.
        // (State/metadata callbacks in MediaSessionHolder will also trigger a refresh
        // automatically, this is just a fast, immediate visual response for the tap.)
        if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            val manager = AppWidgetManager.getInstance(context)
            WidgetUpdater.updateAppWidget(context, manager, appWidgetId)
        } else {
            WidgetUpdater.updateAllWidgets(context)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        appWidgetIds.forEach { WidgetUpdater.forgetWidget(it) }
    }
}
