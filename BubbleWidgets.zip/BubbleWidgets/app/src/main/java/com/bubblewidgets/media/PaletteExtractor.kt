package com.bubblewidgets.media

import android.graphics.Bitmap
import android.graphics.Color
import androidx.palette.graphics.Palette

object PaletteExtractor {

    /**
     * Returns a small list of prominent colors from the artwork, ordered
     * roughly vibrant -> muted. Falls back to the app's default gradient
     * palette if the artwork is missing or too flat to extract from.
     *
     * Colors are pushed toward higher saturation/brightness before being
     * returned -- real album art is often muddy or dark (olive greens,
     * murky browns), which read as "dull" once used for a small UI accent
     * rather than a full photo. Boosting here means the wave and glass
     * buttons stay lively-looking regardless of how vivid the source art
     * actually is.
     *
     * Note: Palette.generate() is synchronous here for simplicity. In a
     * production app, prefer Palette.from(bitmap).generate { palette -> ... }
     * (the async variant) so this never risks a jank frame on the caller's thread.
     */
    fun extractColors(bitmap: Bitmap): IntArray {
        val palette = Palette.from(bitmap).generate()
        val candidates = listOfNotNull(
            palette.vibrantSwatch?.rgb,
            palette.lightVibrantSwatch?.rgb,
            palette.darkVibrantSwatch?.rgb,
            palette.mutedSwatch?.rgb,
            palette.lightMutedSwatch?.rgb,
            palette.darkMutedSwatch?.rgb
        )
        val boosted = candidates.map(::pop).toIntArray()
        return if (boosted.isNotEmpty()) boosted else WaveGenerator.DEFAULT_COLORS
    }

    /** Pushes a color's saturation and brightness up so it reads as vivid, not muddy. */
    private fun pop(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[1] = (hsv[1] * 1.35f).coerceIn(0.55f, 1f)
        hsv[2] = (hsv[2] * 1.15f).coerceIn(0.65f, 1f)
        return Color.HSVToColor(hsv)
    }
}
