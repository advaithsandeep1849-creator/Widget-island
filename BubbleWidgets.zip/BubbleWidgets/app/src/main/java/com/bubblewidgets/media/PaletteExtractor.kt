package com.bubblewidgets.media

import android.graphics.Bitmap
import androidx.palette.graphics.Palette

object PaletteExtractor {

    /**
     * Returns a small list of prominent colors from the artwork, ordered
     * roughly vibrant -> muted. Falls back to the app's default gradient
     * palette if the artwork is missing or too flat to extract from.
     *
     * Note: Palette.generate() is synchronous here for simplicity. In a
     * production app, prefer Palette.from(bitmap).generate { palette -> ... }
     * (the async variant) so this never risks a jank frame on the caller's thread.
     */
    fun extractColors(bitmap: Bitmap): IntArray {
        val palette = Palette.from(bitmap).generate()
        val candidates = listOfNotNull(
            palette.vibrantSwatch?.rgb,
            palette.lightVibrantSwatch?.rgb,
            palette.darkVibrantSwatch?.rgb,
            palette.mutedSwatch?.rgb,
            palette.lightMutedSwatch?.rgb,
            palette.darkMutedSwatch?.rgb
        )
        return if (candidates.isNotEmpty()) candidates.toIntArray() else WaveGenerator.DEFAULT_COLORS
    }
}
