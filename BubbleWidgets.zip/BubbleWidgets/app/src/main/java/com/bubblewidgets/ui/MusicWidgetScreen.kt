package com.bubblewidgets.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bubblewidgets.media.BubbleMediaWidgetProvider
import com.bubblewidgets.media.WidgetOpenAppPrefs
import com.bubblewidgets.ui.theme.AccentMedia
import com.bubblewidgets.ui.theme.GlassFill
import com.bubblewidgets.ui.theme.GlassRim
import com.bubblewidgets.ui.theme.SpaceBlack
import com.bubblewidgets.ui.theme.SpaceIndigo
import com.bubblewidgets.ui.theme.SpaceNavy
import com.bubblewidgets.ui.theme.TextMuted
import com.bubblewidgets.ui.theme.TextPrimary
import com.bubblewidgets.ui.theme.TextSecondary

/**
 * The Media widget's customization screen. Fine-tuning controls (color,
 * which metrics to show, tap-to-open app) come later -- for now this
 * establishes the pattern every future widget screen will follow: a preview
 * up top, options in the middle, and a working "Add to Home Screen" button
 * at the bottom that actually places the widget via requestPinAppWidget,
 * rather than sending the person to the system widget picker.
 */
@Composable
fun MusicWidgetScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var statusMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SpaceBlack, SpaceNavy, SpaceIndigo)))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp, bottom = 24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(GlassFill)
                        .border(1.dp, GlassRim, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Text(
                    "Media Widget",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp)
                )
            }

            Text(
                "Preview",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(end = 8.dp)
            ) {
                item { WidgetPreviewCard(shape = WidgetPreviewShape.WIDE, label = "4x1") }
                item { WidgetPreviewCard(shape = WidgetPreviewShape.COMPACT, label = "2x2") }
                item { WidgetPreviewCard(shape = WidgetPreviewShape.MEDIUM, label = "4x2") }
                item { WidgetPreviewCard(shape = WidgetPreviewShape.FULL, label = "4x4") }
            }

            Text(
                "Fine-tune",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 20.dp, bottom = 10.dp)
            )

            var showAppPicker by remember { mutableStateOf(false) }
            var selectedAppLabel by remember { mutableStateOf(currentDefaultAppLabel(context)) }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(GlassFill)
                    .border(1.dp, GlassRim, RoundedCornerShape(18.dp))
                    .clickable { showAppPicker = true }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Open on tap", color = TextPrimary, fontSize = 15.sp)
                    Text(
                        "Which app opens when you tap the widget's background",
                        color = TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                Text(selectedAppLabel, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(end = 4.dp))
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextMuted)
            }

            Text(
                "More controls (accent color, which metrics to show) are coming here next.",
                color = TextMuted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 12.dp)
            )

            if (showAppPicker) {
                AppPickerDialog(
                    context = context,
                    onDismiss = { showAppPicker = false },
                    onPicked = { label, packageName ->
                        WidgetOpenAppPrefs.setDefaultPackage(context, packageName)
                        selectedAppLabel = label
                        showAppPicker = false
                    }
                )
            }

            Box(modifier = Modifier.weight(1f))

            statusMessage?.let {
                Text(it, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 12.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(AccentMedia, com.bubblewidgets.ui.theme.WordmarkEnd)))
                    .clickable {
                        statusMessage = requestPinMediaWidget(context)
                    }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Add to Home Screen", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun requestPinMediaWidget(context: Context): String {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        return "Pinning widgets from the app needs Android 8.0 or newer -- long-press your home screen instead."
    }
    val appWidgetManager = AppWidgetManager.getInstance(context)
    val provider = ComponentName(context, BubbleMediaWidgetProvider::class.java)
    return if (appWidgetManager.isRequestPinAppWidgetSupported) {
        appWidgetManager.requestPinAppWidget(provider, null, null)
        "Check your home screen to confirm placement."
    } else {
        "Your launcher doesn't support adding widgets this way -- long-press your home screen instead."
    }
}

private fun currentDefaultAppLabel(context: Context): String {
    val packageName = WidgetOpenAppPrefs.getDefaultPackage(context) ?: return "None"
    return try {
        val appInfo = context.packageManager.getApplicationInfo(packageName, 0)
        context.packageManager.getApplicationLabel(appInfo).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        "None"
    }
}

@Composable
private fun AppPickerDialog(
    context: Context,
    onDismiss: () -> Unit,
    onPicked: (label: String, packageName: String?) -> Unit
) {
    val apps = remember {
        context.packageManager
            .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .distinctBy { it.activityInfo.packageName }
            .map { it.activityInfo.packageName to it.loadLabel(context.packageManager).toString() }
            .filter { it.first != context.packageName }
            .sortedBy { it.second.lowercase() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open on tap", color = TextPrimary) },
        containerColor = SpaceNavy,
        text = {
            LazyColumn {
                item {
                    Text(
                        "None",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPicked("None", null) }
                            .padding(vertical = 12.dp)
                    )
                }
                items(apps) { (packageName, label) ->
                    Text(
                        label,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPicked(label, packageName) }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = {
            Text(
                "Cancel",
                color = TextSecondary,
                modifier = Modifier.clickable(onClick = onDismiss).padding(8.dp)
            )
        }
    )
}

private enum class WidgetPreviewShape(val widthDp: Int, val heightDp: Int) {
    WIDE(180, 46),
    COMPACT(96, 96),
    MEDIUM(150, 96),
    FULL(150, 190)
}

/**
 * A lightweight stand-in for the real widget rather than an actual live
 * AppWidgetHostView (which would need binding a host and real playback data)
 * -- close enough to give a sense of the frosted-glass/wave/button look at
 * each size without the complexity of hosting a real widget instance inside
 * an ordinary activity screen.
 */
@Composable
private fun WidgetPreviewCard(shape: WidgetPreviewShape, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(width = shape.widthDp.dp, height = shape.heightDp.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.verticalGradient(listOf(androidx.compose.ui.graphics.Color(0xFF26262B), androidx.compose.ui.graphics.Color(0xFF141416))))
                .border(1.dp, GlassRim, RoundedCornerShape(18.dp))
                .padding(10.dp)
        ) {
            when (shape) {
                WidgetPreviewShape.WIDE -> Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxSize()) {
                    MiniWave(modifier = Modifier.weight(1f).fillMaxSize())
                    MiniButtonPill(modifier = Modifier.padding(start = 6.dp), buttonSize = 14.dp, centerSize = 20.dp)
                }
                WidgetPreviewShape.COMPACT -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxSize()
                ) {
                    MiniWave(modifier = Modifier.weight(1f).fillMaxWidth())
                    MiniButtonPill(modifier = Modifier.padding(top = 6.dp), buttonSize = 10.dp, centerSize = 16.dp)
                }
                WidgetPreviewShape.MEDIUM -> Column(modifier = Modifier.fillMaxSize()) {
                    MiniWave(modifier = Modifier.weight(1f).fillMaxWidth())
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Brush.horizontalGradient(listOf(AccentMedia, androidx.compose.ui.graphics.Color(0xFFB03BFF))))
                    )
                    MiniButtonPill(modifier = Modifier.padding(top = 6.dp).fillMaxWidth(), buttonSize = 12.dp, centerSize = 18.dp, fillWidth = true)
                }
                WidgetPreviewShape.FULL -> Column(modifier = Modifier.fillMaxSize()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = TextMuted, modifier = Modifier.size(10.dp))
                        Text("This phone", color = TextMuted, fontSize = 8.sp, modifier = Modifier.padding(start = 4.dp))
                    }
                    MiniWave(modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Brush.horizontalGradient(listOf(AccentMedia, androidx.compose.ui.graphics.Color(0xFFB03BFF))))
                    )
                    MiniButtonPill(modifier = Modifier.padding(top = 8.dp).fillMaxWidth(), buttonSize = 16.dp, centerSize = 24.dp, fillWidth = true)
                }
            }
        }
        Text(label, color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun MiniWave(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.verticalGradient(
                    listOf(AccentMedia.copy(alpha = 0.45f), androidx.compose.ui.graphics.Color(0xFFB03BFF).copy(alpha = 0.25f))
                )
            )
    )
}

@Composable
private fun MiniButtonPill(modifier: Modifier = Modifier, buttonSize: androidx.compose.ui.unit.Dp, centerSize: androidx.compose.ui.unit.Dp, fillWidth: Boolean = false) {
    Row(
        modifier = modifier
            .let { if (fillWidth) it else it }
            .clip(RoundedCornerShape(50))
            .background(GlassFill)
            .border(1.dp, GlassRim, RoundedCornerShape(50))
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = if (fillWidth) androidx.compose.foundation.layout.Arrangement.SpaceEvenly else androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(buttonSize).clip(CircleShape).background(TextSecondary.copy(alpha = 0.5f)))
        Box(modifier = Modifier.size(centerSize).clip(CircleShape).background(TextPrimary.copy(alpha = 0.85f)))
        Box(modifier = Modifier.size(buttonSize).clip(CircleShape).background(TextSecondary.copy(alpha = 0.5f)))
    }
}
