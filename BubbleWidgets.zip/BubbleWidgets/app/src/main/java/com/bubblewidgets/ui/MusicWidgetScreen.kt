package com.bubblewidgets.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.bubblewidgets.media.BubbleMediaWidgetProvider
import com.bubblewidgets.ui.theme.AccentMedia
import com.bubblewidgets.ui.theme.GlassFill
import com.bubblewidgets.ui.theme.GlassRim
import com.bubblewidgets.ui.theme.SpaceBlack
import com.bubblewidgets.ui.theme.SpaceIndigo
import com.bubblewidgets.ui.theme.SpaceNavy
import com.bubblewidgets.ui.theme.TextMuted
import com.bubblewidgets.ui.theme.TextPrimary
import com.bubblewidgets.ui.theme.TextSecondary

/**
 * The Media widget's customization screen. Fine-tuning controls (color,
 * which metrics to show, tap-to-open app) come later -- for now this
 * establishes the pattern every future widget screen will follow: a preview
 * up top, options in the middle, and a working "Add to Home Screen" button
 * at the bottom that actually places the widget via requestPinAppWidget,
 * rather than sending the person to the system widget picker.
 */
@Composable
fun MusicWidgetScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var statusMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SpaceBlack, SpaceNavy, SpaceIndigo)))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp, bottom = 24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(GlassFill)
                        .border(1.dp, GlassRim, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Text(
                    "Media Widget",
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp)
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(GlassFill, androidx.compose.ui.graphics.Color.Transparent)))
                    .border(1.dp, GlassRim, RoundedCornerShape(28.dp))
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(AccentMedia.copy(alpha = 0.4f), AccentMedia.copy(alpha = 0.08f)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.MusicNote, contentDescription = null, tint = AccentMedia)
                    }
                    Text(
                        "Now-playing widget",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                    Text(
                        "Frosted glass, live album art, and a color-reactive wave.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Text(
                "Fine-tune options (color, tap-to-open app, and more) are coming here next.",
                color = TextMuted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 20.dp)
            )

            Box(modifier = Modifier.weight(1f))

            statusMessage?.let {
                Text(it, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 12.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(AccentMedia, com.bubblewidgets.ui.theme.WordmarkEnd)))
                    .clickable {
                        statusMessage = requestPinMediaWidget(context)
                    }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Add to Home Screen", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun requestPinMediaWidget(context: Context): String {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        return "Pinning widgets from the app needs Android 8.0 or newer -- long-press your home screen instead."
    }
    val appWidgetManager = AppWidgetManager.getInstance(context)
    val provider = ComponentName(context, BubbleMediaWidgetProvider::class.java)
    return if (appWidgetManager.isRequestPinAppWidgetSupported) {
        appWidgetManager.requestPinAppWidget(provider, null, null)
        "Check your home screen to confirm placement."
    } else {
        "Your launcher doesn't support adding widgets this way -- long-press your home screen instead."
    }
}
