package com.bubblewidgets.media

import android.content.Context
import android.media.session.MediaController
import android.media.session.PlaybackState

/**
 * Keeps a reference to whichever media session on the device is currently
 * "active" (the one the system considers the current now-playing session),
 * and exposes simple control functions the widget's buttons call into.
 *
 * This is intentionally a plain in-memory singleton: it's refreshed by
 * [MediaNotificationListener] whenever the system reports session changes,
 * and read by [BubbleMediaWidgetProvider] whenever a widget needs to redraw
 * or a button is tapped.
 */
object MediaSessionHolder {

    var controller: MediaController? = null
        private set

    private var callback: MediaController.Callback? = null
    private var onChanged: (() -> Unit)? = null

    fun setOnChangedListener(listener: (() -> Unit)?) {
        onChanged = listener
    }

    fun attach(newController: MediaController?) {
        // detach old callback first
        callback?.let { controller?.unregisterCallback(it) }

        controller = newController
        if (newController == null) {
            callback = null
            return
        }

        val cb = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                onChanged?.invoke()
            }

            override fun onMetadataChanged(metadata: android.media.MediaMetadata?) {
                onChanged?.invoke()
            }

            override fun onSessionDestroyed() {
                attach(null)
                onChanged?.invoke()
            }
        }
        newController.registerCallback(cb)
        callback = cb
    }

    fun isPlaying(): Boolean {
        val state = controller?.playbackState?.state
        return state == PlaybackState.STATE_PLAYING
    }

    fun playPause() {
        val c = controller ?: return
        if (isPlaying()) c.transportControls.pause() else c.transportControls.play()
    }

    fun skipNext() = controller?.transportControls?.skipToNext()

    fun skipPrevious() = controller?.transportControls?.skipToPrevious()

    /**
     * The plain framework MediaController/PlaybackState APIs used throughout
     * this class do not expose shuffle state at all (that only exists on the
     * separate, older support-library MediaControllerCompat/PlaybackStateCompat
     * classes, which this project does not depend on). Most apps that support
     * shuffle still accept it as a custom PlaybackState action, so we try that
     * the same way [toggleFavoriteIfSupported] does; otherwise this is a no-op.
     */
    fun toggleShuffle(): Boolean {
        val c = controller ?: return false
        val customActions = c.playbackState?.customActions ?: return false
        val match = customActions.firstOrNull {
            it.action.contains("shuffle", ignoreCase = true)
        } ?: return false
        c.transportControls.sendCustomAction(match, null)
        return true
    }

    /**
     * "Favorite" / "add to library" isn't part of the standard MediaSession
     * transport API — each app (Spotify, YT Music, etc.) exposes it, if at
     * all, as a custom PlaybackState action. We look for one by common names
     * and fire it if present; otherwise this is a no-op.
     */
    fun toggleFavoriteIfSupported(): Boolean {
        val c = controller ?: return false
        val customActions = c.playbackState?.customActions ?: return false
        val match = customActions.firstOrNull {
            it.action.contains("favorite", ignoreCase = true) ||
                it.action.contains("like", ignoreCase = true) ||
                it.action.contains("thumb", ignoreCase = true)
        } ?: return false
        c.transportControls.sendCustomAction(match, null)
        return true
    }
}
