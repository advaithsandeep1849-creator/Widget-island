package com.bubblewidgets.health

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BubbleHealthWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        refreshAll(context, appWidgetIds)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        manager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        refreshAll(context, intArrayOf(appWidgetId))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, BubbleHealthWidgetProvider::class.java))
            refreshAll(context, ids)
        }
    }

    /**
     * Health Connect reads are suspend functions (local DB reads, but still
     * async) -- goAsync() extends how long the broadcast receiver is allowed
     * to keep running past onUpdate() returning, which a plain synchronous
     * RemoteViews build (like the music widget's) never needed.
     */
    private fun refreshAll(context: Context, appWidgetIds: IntArray) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val snapshot = HealthDataProvider.readTodaySnapshot(context)
                val manager = AppWidgetManager.getInstance(context)
                appWidgetIds.forEach { id -> HealthWidgetUpdater.updateAppWidget(context, manager, id, snapshot) }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.bubblewidgets.health.ACTION_REFRESH"
    }
}
