package com.bubblewidgets.media

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView

/**
 * Runs when a widget is first placed (and again if the user picks "Widget
 * settings" from the long-press menu -- the widget declares itself
 * reconfigurable). Lets the user choose which app opens when they tap the
 * widget's background, anywhere that isn't one of the transport buttons.
 */
class WidgetConfigureActivity : Activity() {

    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If the user backs out without picking anything, the widget host
        // should treat this as a cancelled placement.
        setResult(RESULT_CANCELED)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 48, 32, 16)
        }
        val title = TextView(this).apply {
            text = "Open this app when the widget is tapped"
            textSize = 18f
            setPadding(0, 0, 0, 24)
        }
        val listView = ListView(this)
        root.addView(title)
        root.addView(
            listView,
            android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        setContentView(root)

        // "None" first, so the user can explicitly leave tap-to-open unset --
        // in that case the background just isn't clickable, only the
        // transport buttons are (today's default behavior).
        val launchables = packageManager
            .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .distinctBy { it.activityInfo.packageName }
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName } // don't offer to open ourselves
            .sortedBy { it.second.lowercase() }

        val labels = listOf("None (don't open anything)") + launchables.map { it.second }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)

        listView.setOnItemClickListener { _, _, position, _ ->
            if (position == 0) {
                WidgetOpenAppPrefs.clear(this, appWidgetId)
            } else {
                val chosenPackage = launchables[position - 1].first
                WidgetOpenAppPrefs.setPackage(this, appWidgetId, chosenPackage)
            }

            WidgetUpdater.updateAppWidget(this, AppWidgetManager.getInstance(this), appWidgetId)

            val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            setResult(RESULT_OK, resultValue)
            finish()
        }
    }
}
