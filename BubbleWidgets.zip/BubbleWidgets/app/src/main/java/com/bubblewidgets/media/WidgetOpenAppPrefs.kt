package com.bubblewidgets.media

import android.content.Context

/**
 * Remembers which app (by package name) each individual widget instance
 * should open when the user taps the background of the widget -- anywhere
 * that isn't one of the transport buttons.
 *
 * Two ways this gets set:
 * - Per-widget, via [WidgetConfigureActivity] (the system's own "Widget
 *   settings" flow, reachable by long-pressing an already-placed widget).
 * - A "default" choice made in-app, on the Media widget's customization
 *   screen, BEFORE the widget is placed -- since requestPinAppWidget doesn't
 *   hand back a widget ID until after the person confirms placement, there's
 *   no specific instance to attach the choice to yet. [getPackage] falls
 *   back to this default when a widget has no specific choice of its own,
 *   which is what lets a pre-placement choice actually take effect on the
 *   widget that gets placed next.
 */
object WidgetOpenAppPrefs {
    private const val PREFS_NAME = "widget_open_app_prefs"
    private const val KEY_PREFIX = "open_app_"
    private const val KEY_DEFAULT = "open_app_default"

    fun setPackage(context: Context, appWidgetId: Int, packageName: String) {
        prefs(context).edit().putString(KEY_PREFIX + appWidgetId, packageName).apply()
    }

    fun getPackage(context: Context, appWidgetId: Int): String? =
        prefs(context).getString(KEY_PREFIX + appWidgetId, null) ?: getDefaultPackage(context)

    fun clear(context: Context, appWidgetId: Int) {
        prefs(context).edit().remove(KEY_PREFIX + appWidgetId).apply()
    }

    fun setDefaultPackage(context: Context, packageName: String?) {
        val editor = prefs(context).edit()
        if (packageName == null) editor.remove(KEY_DEFAULT) else editor.putString(KEY_DEFAULT, packageName)
        editor.apply()
    }

    fun getDefaultPackage(context: Context): String? =
        prefs(context).getString(KEY_DEFAULT, null)

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
