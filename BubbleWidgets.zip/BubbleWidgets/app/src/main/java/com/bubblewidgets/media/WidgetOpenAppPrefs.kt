package com.bubblewidgets.media

import android.content.Context

/**
 * Remembers which app (by package name) each individual widget instance
 * should open when the user taps the background of the widget -- anywhere
 * that isn't one of the transport buttons. Set via [WidgetConfigureActivity],
 * which runs automatically when a widget is first placed (and again if the
 * user picks "Widget settings" from the long-press menu, since the widget
 * declares itself reconfigurable).
 */
object WidgetOpenAppPrefs {
    private const val PREFS_NAME = "widget_open_app_prefs"
    private const val KEY_PREFIX = "open_app_"

    fun setPackage(context: Context, appWidgetId: Int, packageName: String) {
        prefs(context).edit().putString(KEY_PREFIX + appWidgetId, packageName).apply()
    }

    fun getPackage(context: Context, appWidgetId: Int): String? =
        prefs(context).getString(KEY_PREFIX + appWidgetId, null)

    fun clear(context: Context, appWidgetId: Int) {
        prefs(context).edit().remove(KEY_PREFIX + appWidgetId).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
