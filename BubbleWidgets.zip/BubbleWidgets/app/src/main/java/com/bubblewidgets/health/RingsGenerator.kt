package com.bubblewidgets.health

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * Draws 4 concentric progress rings (steps/calories/active-time/sleep),
 * glass-styled to match the rest of the app: a dim full-circle track behind
 * each ring, a bright rounded-cap progress arc on top, and a soft highlight
 * near the start of each arc for a glossy look. Ring order matches the
 * reference image -- outermost is sleep, innermost is steps.
 */
object RingsGenerator {

    private const val SIZE = 480
    private const val RING_COUNT = 4
    private const val RING_THICKNESS = 34f
    private const val RING_GAP = 10f

    /** One ring's progress (0f..1f, already clamped) and its color. */
    data class Ring(val progress: Float, val color: Int)

    fun generate(rings: List<Ring>): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val center = SIZE / 2f
        val outerRadius = center - RING_THICKNESS / 2f - 6f

        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = RING_THICKNESS
            strokeCap = Paint.Cap.ROUND
        }
        val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = RING_THICKNESS
            strokeCap = Paint.Cap.ROUND
        }
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = RING_THICKNESS + 10f
            strokeCap = Paint.Cap.ROUND
        }

        rings.take(RING_COUNT).forEachIndexed { index, ring ->
            val radius = outerRadius - index * (RING_THICKNESS + RING_GAP)
            val rect = RectF(center - radius, center - radius, center + radius, center + radius)

            // dim track (full circle)
            trackPaint.color = ring.color
            trackPaint.alpha = 40
            canvas.drawArc(rect, 0f, 360f, false, trackPaint)

            // soft outer glow along the progress arc only
            glowPaint.color = ring.color
            glowPaint.alpha = 60
            canvas.drawArc(rect, -90f, 360f * ring.progress, false, glowPaint)

            // bright progress arc, starting from 12 o'clock, clockwise
            progressPaint.color = ring.color
            progressPaint.alpha = 235
            canvas.drawArc(rect, -90f, 360f * ring.progress, false, progressPaint)

            // small glossy highlight near the arc's start
            if (ring.progress > 0.02f) {
                val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = RING_THICKNESS * 0.4f
                    strokeCap = Paint.Cap.ROUND
                    color = 0x59FFFFFF
                }
                canvas.drawArc(rect, -90f, minOf(18f, 360f * ring.progress), false, highlightPaint)
            }
        }

        return bmp
    }
}
