package com.bubblewidgets.media

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.session.PlaybackState
import android.widget.RemoteViews
import com.bubblewidgets.R
import java.util.concurrent.TimeUnit

object WidgetUpdater {

    const val ACTION_PLAY_PAUSE = "com.bubblewidgets.ACTION_PLAY_PAUSE"
    const val ACTION_NEXT = "com.bubblewidgets.ACTION_NEXT"
    const val ACTION_PREV = "com.bubblewidgets.ACTION_PREV"
    const val ACTION_SHUFFLE = "com.bubblewidgets.ACTION_SHUFFLE"
    const val ACTION_FAVORITE = "com.bubblewidgets.ACTION_FAVORITE"

    /**
     * Four hand-tuned size buckets rather than one continuously-scaling
     * layout -- RemoteViews has no real way to keep circular buttons
     * proportional to the widget's live size on every supported OS version,
     * so instead each bucket gets its own layout with buttons sized right
     * for that range. COMPACT/WIDE/MEDIUM/FULL roughly correspond to a small
     * square (2x2), a short wide bar (4x1), a taller bar (4x2), and the
     * full-size player.
     */
    private enum class Bucket { COMPACT, WIDE, MEDIUM, FULL }

    // Width below this is always COMPACT regardless of height -- this is the
    // widget's small-square shape, distinct from the wider bar shapes.
    private const val COMPACT_WIDTH_THRESHOLD_DP = 180
    private const val WIDE_HEIGHT_THRESHOLD_DP = 90
    private const val MEDIUM_HEIGHT_THRESHOLD_DP = 160

    // Widget instances whose current layout has no wave ImageView --
    // updateWaveFrame skips these. Only FULL has the wave.
    private val noWaveWidgetIds = mutableSetOf<Int>()

    fun updateAllWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, BubbleMediaWidgetProvider::class.java))
        ids.forEach { id -> updateAppWidget(context, manager, id) }
    }

    private fun determineBucket(manager: AppWidgetManager, appWidgetId: Int): Bucket {
        val options = manager.getAppWidgetOptions(appWidgetId)
        val width = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            ?.takeIf { it > 0 }
            ?: options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0) ?: 0
        val height = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            ?.takeIf { it > 0 }
            ?: options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0) ?: 0

        // No size reported yet (can happen right at initial placement) --
        // default to compact, this widget's declared minimum/target size.
        if (width == 0) return Bucket.COMPACT

        return when {
            width < COMPACT_WIDTH_THRESHOLD_DP -> Bucket.COMPACT
            height in 1 until WIDE_HEIGHT_THRESHOLD_DP -> Bucket.WIDE
            height in WIDE_HEIGHT_THRESHOLD_DP until MEDIUM_HEIGHT_THRESHOLD_DP -> Bucket.MEDIUM
            height == 0 -> Bucket.COMPACT // width known but height unreported -- be conservative
            else -> Bucket.FULL
        }
    }

    private fun layoutFor(bucket: Bucket): Int = when (bucket) {
        Bucket.COMPACT -> R.layout.widget_bubble_media_player_compact
        Bucket.WIDE -> R.layout.widget_bubble_media_player_wide
        Bucket.MEDIUM -> R.layout.widget_bubble_media_player_medium
        Bucket.FULL -> R.layout.widget_bubble_media_player
    }

    fun updateAppWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
        val bucket = determineBucket(manager, appWidgetId)
        val views = RemoteViews(context.packageName, layoutFor(bucket))

        val controller = MediaSessionHolder.controller
        val metadata = controller?.metadata
        val state = controller?.playbackState

        val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
            ?: context.getString(R.string.no_media)
        val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val durationMs = metadata?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val positionMs = state?.position ?: 0L
        val isPlaying = state?.state == PlaybackState.STATE_PLAYING
        val playPauseIcon = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        val progress = if (durationMs > 0) {
            ((positionMs.toDouble() / durationMs.toDouble()) * 1000).toInt().coerceIn(0, 1000)
        } else 0

        val artBitmap = metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART)

        if (bucket == Bucket.COMPACT) {
            views.setTextViewText(R.id.text_title_compact, title)
            views.setImageViewResource(R.id.button_play_pause_compact, playPauseIcon)
            views.setProgressBar(R.id.progress_seek_compact, 1000, progress, false)
            if (artBitmap != null) {
                views.setImageViewBitmap(R.id.image_background_art_compact, BackgroundArtProcessor.process(artBitmap))
                views.setFloat(R.id.image_background_art_compact, "setAlpha", 0.55f)
                WaveEngine.setPaletteColors(PaletteExtractor.extractColors(artBitmap))
            } else {
                views.setImageViewResource(R.id.image_background_art_compact, R.drawable.bg_art_placeholder_full)
            }
            bindAction(context, views, R.id.button_play_pause_compact, ACTION_PLAY_PAUSE, appWidgetId)
            bindAction(context, views, R.id.button_next_compact, ACTION_NEXT, appWidgetId)
            bindAction(context, views, R.id.button_previous_compact, ACTION_PREV, appWidgetId)
            bindOpenAppOnTap(context, views, R.id.widget_root_compact, appWidgetId)
        } else {
            // WIDE/MEDIUM/FULL all share the same view ID scheme (text_title,
            // button_previous, image_album_art, etc.) even though WIDE and
            // MEDIUM don't have every view FULL does (text_artist, the wave,
            // time labels) -- RemoteViews silently no-ops any action whose
            // target id isn't present in the currently inflated layout, so
            // this single block safely covers all three.
            views.setTextViewText(R.id.text_title, title)
            views.setTextViewText(R.id.text_artist, artist)
            views.setTextViewText(R.id.text_position, formatTime(positionMs))
            views.setTextViewText(R.id.text_duration, formatTime(durationMs))
            views.setImageViewResource(R.id.button_play_pause, playPauseIcon)
            views.setProgressBar(R.id.progress_seek, 1000, progress, false)

            // Album art: pull the real bitmap from the media session's metadata.
            // It goes to two places -- the small rounded thumbnail, and the
            // full-bleed background behind the frosted overlay. We also use
            // it to feed the wave animation's color palette.
            if (artBitmap != null) {
                views.setImageViewBitmap(R.id.image_album_art, roundCorners(artBitmap, 24f))
                views.setImageViewBitmap(R.id.image_background_art, BackgroundArtProcessor.process(artBitmap))
                // Faded to a subtle silhouette rather than a full vivid photo --
                // "etched into the glass" rather than a background image
                // sitting behind the panel.
                views.setFloat(R.id.image_background_art, "setAlpha", 0.55f)
                WaveEngine.setPaletteColors(PaletteExtractor.extractColors(artBitmap))
            } else {
                views.setImageViewResource(R.id.image_album_art, R.drawable.album_art_placeholder)
                views.setImageViewResource(R.id.image_background_art, R.drawable.bg_art_placeholder_full)
            }

            // "Favorite" icon: we can only reflect a filled/liked state if the
            // source app exposes it via a custom action's boolean state — most
            // don't expose this readably, so we default to the outline heart.
            views.setImageViewResource(R.id.button_favorite, R.drawable.ic_heart_outline)

            bindAction(context, views, R.id.button_play_pause, ACTION_PLAY_PAUSE, appWidgetId)
            bindAction(context, views, R.id.button_next, ACTION_NEXT, appWidgetId)
            bindAction(context, views, R.id.button_previous, ACTION_PREV, appWidgetId)
            bindAction(context, views, R.id.button_favorite, ACTION_FAVORITE, appWidgetId)
            bindOpenAppOnTap(context, views, R.id.widget_root, appWidgetId)
        }

        if (bucket == Bucket.FULL) {
            noWaveWidgetIds.remove(appWidgetId)
        } else {
            noWaveWidgetIds.add(appWidgetId)
        }

        manager.updateAppWidget(appWidgetId, views)

        // Flip the wave animation to "playing" or "settling" to match reality.
        // Both calls are cheap no-ops if the engine is already in that state.
        if (isPlaying) {
            WaveAnimationService.startPlaying(context)
        } else {
            WaveAnimationService.triggerSettle(context)
        }
    }

    /** Call when a widget instance is removed from the home screen, to release its cached state. */
    fun forgetWidget(appWidgetId: Int) {
        noWaveWidgetIds.remove(appWidgetId)
    }

    fun updateWaveFrame(context: Context, bitmap: Bitmap) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, BubbleMediaWidgetProvider::class.java))
        ids.forEach { id ->
            if (id in noWaveWidgetIds) return@forEach // current layout has no wave ImageView
            // Send a small, fresh RemoteViews containing ONLY the wave-image
            // action, via partiallyUpdateAppWidget, instead of re-sending the
            // full cached RemoteViews (which carries the album-art bitmaps
            // too, and -- since RemoteViews actions accumulate rather than
            // replace -- was growing every single frame). This is what was
            // actually causing the choppiness: ~10x/sec IPC transfers that
            // grew heavier the longer playback ran.
            val partial = RemoteViews(context.packageName, R.layout.widget_bubble_media_player)
            partial.setImageViewBitmap(R.id.image_wave, bitmap)
            manager.partiallyUpdateAppWidget(id, partial)
        }
    }

    private fun bindAction(
        context: Context,
        views: RemoteViews,
        viewId: Int,
        action: String,
        appWidgetId: Int
    ) {
        val intent = Intent(context, BubbleMediaWidgetProvider::class.java).apply {
            this.action = action
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }
        val pendingIntent = android.app.PendingIntent.getBroadcast(
            context,
            // unique request code per (widget, action) pair so intents don't collide
            appWidgetId * 10 + action.hashCode() % 10,
            intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(viewId, pendingIntent)
    }

    private fun bindOpenAppOnTap(context: Context, views: RemoteViews, rootViewId: Int, appWidgetId: Int) {
        val chosenPackage = WidgetOpenAppPrefs.getPackage(context, appWidgetId) ?: return
        val launchIntent = context.packageManager.getLaunchIntentForPackage(chosenPackage) ?: return
        val pendingIntent = android.app.PendingIntent.getActivity(
            context,
            appWidgetId, // unique per widget instance, distinct request-code space from bindAction's
            launchIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(rootViewId, pendingIntent)
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(ms)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    private fun roundCorners(bitmap: Bitmap, radiusPx: Float): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val rect = RectF(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat())
        canvas.drawRoundRect(rect, radiusPx, radiusPx, paint)
        return output
    }
}
