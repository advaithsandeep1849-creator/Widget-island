package com.bubblewidgets.media

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.session.PlaybackState
import android.widget.RemoteViews
import com.bubblewidgets.R
import java.util.concurrent.TimeUnit

object WidgetUpdater {

    const val ACTION_PLAY_PAUSE = "com.bubblewidgets.ACTION_PLAY_PAUSE"
    const val ACTION_NEXT = "com.bubblewidgets.ACTION_NEXT"
    const val ACTION_PREV = "com.bubblewidgets.ACTION_PREV"
    const val ACTION_SHUFFLE = "com.bubblewidgets.ACTION_SHUFFLE"
    const val ACTION_FAVORITE = "com.bubblewidgets.ACTION_FAVORITE"

    // Keeps the last built RemoteViews per widget instance so wave-animation
    // frames (pushed ~8x/sec while playing) can patch just the wave ImageView
    // and re-push, instead of rebuilding the whole widget every tick.
    private val cachedViews = mutableMapOf<Int, RemoteViews>()

    fun updateAllWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, BubbleMediaWidgetProvider::class.java))
        ids.forEach { id -> updateAppWidget(context, manager, id) }
    }

    fun updateAppWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_bubble_media_player)
        val controller = MediaSessionHolder.controller
        val metadata = controller?.metadata
        val state = controller?.playbackState

        val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
            ?: context.getString(R.string.no_media)
        val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val durationMs = metadata?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val positionMs = state?.position ?: 0L
        val isPlaying = state?.state == PlaybackState.STATE_PLAYING

        views.setTextViewText(R.id.text_title, title)
        views.setTextViewText(R.id.text_artist, artist)
        views.setTextViewText(R.id.text_position, formatTime(positionMs))
        views.setTextViewText(R.id.text_duration, formatTime(durationMs))
        views.setImageViewResource(
            R.id.button_play_pause,
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )

        if (durationMs > 0) {
            val progress = ((positionMs.toDouble() / durationMs.toDouble()) * 1000).toInt()
            views.setProgressBar(R.id.progress_seek, 1000, progress.coerceIn(0, 1000), false)
        } else {
            views.setProgressBar(R.id.progress_seek, 1000, 0, false)
        }

        // Album art: pull the real bitmap from the media session's metadata,
        // round its corners to match the panel style, and hand it to the ImageView.
        // We also use it to paint the widget's blurred background and to feed
        // the wave animation's color palette.
        val artBitmap = metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART)
        if (artBitmap != null) {
            views.setImageViewBitmap(R.id.image_album_art, roundCorners(artBitmap, 24f))
            views.setImageViewBitmap(R.id.image_background_art, BackgroundArtProcessor.process(artBitmap))
            WaveEngine.setPaletteColors(PaletteExtractor.extractColors(artBitmap))
        } else {
            views.setImageViewResource(R.id.image_album_art, R.drawable.album_art_placeholder)
            views.setImageViewResource(R.id.image_background_art, R.drawable.album_art_placeholder)
        }

        // "Favorite" icon: we can only reflect a filled/liked state if the
        // source app exposes it via a custom action's boolean state — most
        // don't expose this readably, so we default to the outline heart.
        views.setImageViewResource(R.id.button_favorite, R.drawable.ic_heart_outline)

        bindAction(context, views, R.id.button_play_pause, ACTION_PLAY_PAUSE, appWidgetId)
        bindAction(context, views, R.id.button_next, ACTION_NEXT, appWidgetId)
        bindAction(context, views, R.id.button_previous, ACTION_PREV, appWidgetId)
        bindAction(context, views, R.id.button_shuffle, ACTION_SHUFFLE, appWidgetId)
        bindAction(context, views, R.id.button_favorite, ACTION_FAVORITE, appWidgetId)

        cachedViews[appWidgetId] = views
        manager.updateAppWidget(appWidgetId, views)

        // Flip the wave animation to "playing" or "settling" to match reality.
        // Both calls are cheap no-ops if the engine is already in that state.
        if (isPlaying) {
            WaveAnimationService.startPlaying(context)
        } else {
            WaveAnimationService.triggerSettle(context)
        }
    }

    /**
     * Called ~8x/second by [WaveAnimationService] while the wave is animating.
     * Patches only the wave ImageView on the cached RemoteViews for each
     * placed widget instance, rather than rebuilding everything from scratch.
     */
    /** Call when a widget instance is removed from the home screen, to release its cached views. */
    fun forgetWidget(appWidgetId: Int) {
        cachedViews.remove(appWidgetId)
    }

    fun updateWaveFrame(context: Context, bitmap: Bitmap) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, BubbleMediaWidgetProvider::class.java))
        ids.forEach { id ->
            val views = cachedViews[id] ?: return@forEach
            views.setImageViewBitmap(R.id.image_wave, bitmap)
            manager.updateAppWidget(id, views)
        }
    }

    private fun bindAction(
        context: Context,
        views: RemoteViews,
        viewId: Int,
        action: String,
        appWidgetId: Int
    ) {
        val intent = Intent(context, BubbleMediaWidgetProvider::class.java).apply {
            this.action = action
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }
        val pendingIntent = android.app.PendingIntent.getBroadcast(
            context,
            // unique request code per (widget, action) pair so intents don't collide
            appWidgetId * 10 + action.hashCode() % 10,
            intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(viewId, pendingIntent)
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(ms)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    private fun roundCorners(bitmap: Bitmap, radiusPx: Float): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val rect = RectF(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat())
        canvas.drawRoundRect(rect, radiusPx, radiusPx, paint)
        return output
    }
}
