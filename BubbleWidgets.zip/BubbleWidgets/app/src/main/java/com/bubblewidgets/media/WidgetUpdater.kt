package com.bubblewidgets.media

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.session.PlaybackState
import android.widget.RemoteViews
import com.bubblewidgets.R
import java.util.concurrent.TimeUnit

object WidgetUpdater {

    const val ACTION_PLAY_PAUSE = "com.bubblewidgets.ACTION_PLAY_PAUSE"
    const val ACTION_NEXT = "com.bubblewidgets.ACTION_NEXT"
    const val ACTION_PREV = "com.bubblewidgets.ACTION_PREV"
    const val ACTION_SHUFFLE = "com.bubblewidgets.ACTION_SHUFFLE"
    const val ACTION_FAVORITE = "com.bubblewidgets.ACTION_FAVORITE"

    // Below this width, we use the compact (2x2-friendly) layout instead of
    // the full player. 180dp comfortably fits a 3-cell-wide widget on most
    // launchers while still excluding true 2-cell (~110dp) placements.
    private const val COMPACT_WIDTH_THRESHOLD_DP = 180

    // Keeps the last built RemoteViews per widget instance so wave-animation
    // frames (pushed ~8x/sec while playing) can patch just the wave ImageView
    // and re-push, instead of rebuilding the whole widget every tick.
    private val cachedViews = mutableMapOf<Int, RemoteViews>()

    // Widget instances currently showing the compact layout, which has no
    // wave ImageView to patch — updateWaveFrame skips these.
    private val compactWidgetIds = mutableSetOf<Int>()

    fun updateAllWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, BubbleMediaWidgetProvider::class.java))
        ids.forEach { id -> updateAppWidget(context, manager, id) }
    }

    private fun isCompactSize(manager: AppWidgetManager, appWidgetId: Int): Boolean {
        val options = manager.getAppWidgetOptions(appWidgetId) ?: return false
        // Use whichever width the launcher has actually reported; some launchers
        // only fill in one of these depending on orientation/state.
        val width = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            .takeIf { it > 0 }
            ?: options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
        // width == 0 means the launcher hasn't reported a size yet (can happen
        // right at initial placement) — default to compact since that's now
        // this widget's declared minimum/target size.
        return width == 0 || width < COMPACT_WIDTH_THRESHOLD_DP
    }

    fun updateAppWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
        val compact = isCompactSize(manager, appWidgetId)
        val views = RemoteViews(
            context.packageName,
            if (compact) R.layout.widget_bubble_media_player_compact else R.layout.widget_bubble_media_player
        )
        val controller = MediaSessionHolder.controller
        val metadata = controller?.metadata
        val state = controller?.playbackState

        val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
            ?: context.getString(R.string.no_media)
        val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val durationMs = metadata?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val positionMs = state?.position ?: 0L
        val isPlaying = state?.state == PlaybackState.STATE_PLAYING
        val playPauseIcon = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        val progress = if (durationMs > 0) {
            ((positionMs.toDouble() / durationMs.toDouble()) * 1000).toInt().coerceIn(0, 1000)
        } else 0

        val artBitmap = metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART)

        if (compact) {
            views.setTextViewText(R.id.text_title_compact, title)
            views.setImageViewResource(R.id.button_play_pause_compact, playPauseIcon)
            views.setProgressBar(R.id.progress_seek_compact, 1000, progress, false)
            if (artBitmap != null) {
                views.setImageViewBitmap(R.id.image_background_art_compact, BackgroundArtProcessor.process(artBitmap))
                WaveEngine.setPaletteColors(PaletteExtractor.extractColors(artBitmap))
            } else {
                views.setImageViewResource(R.id.image_background_art_compact, R.drawable.album_art_placeholder)
            }
            bindAction(context, views, R.id.button_play_pause_compact, ACTION_PLAY_PAUSE, appWidgetId)
            bindAction(context, views, R.id.button_next_compact, ACTION_NEXT, appWidgetId)
            bindAction(context, views, R.id.button_previous_compact, ACTION_PREV, appWidgetId)
            compactWidgetIds.add(appWidgetId)
        } else {
            views.setTextViewText(R.id.text_title, title)
            views.setTextViewText(R.id.text_artist, artist)
            views.setTextViewText(R.id.text_position, formatTime(positionMs))
            views.setTextViewText(R.id.text_duration, formatTime(durationMs))
            views.setImageViewResource(R.id.button_play_pause, playPauseIcon)
            views.setProgressBar(R.id.progress_seek, 1000, progress, false)

            // Album art: pull the real bitmap from the media session's metadata,
            // round its corners to match the panel style, and hand it to the ImageView.
            // We also use it to paint the widget's blurred background and to feed
            // the wave animation's color palette.
            if (artBitmap != null) {
                views.setImageViewBitmap(R.id.image_album_art, roundCorners(artBitmap, 24f))
                views.setImageViewBitmap(R.id.image_background_art, BackgroundArtProcessor.process(artBitmap))
                WaveEngine.setPaletteColors(PaletteExtractor.extractColors(artBitmap))
            } else {
                views.setImageViewResource(R.id.image_album_art, R.drawable.album_art_placeholder)
                views.setImageViewResource(R.id.image_background_art, R.drawable.album_art_placeholder)
            }

            // "Favorite" icon: we can only reflect a filled/liked state if the
            // source app exposes it via a custom action's boolean state — most
            // don't expose this readably, so we default to the outline heart.
            views.setImageViewResource(R.id.button_favorite, R.drawable.ic_heart_outline)

            bindAction(context, views, R.id.button_play_pause, ACTION_PLAY_PAUSE, appWidgetId)
            bindAction(context, views, R.id.button_next, ACTION_NEXT, appWidgetId)
            bindAction(context, views, R.id.button_previous, ACTION_PREV, appWidgetId)
            bindAction(context, views, R.id.button_shuffle, ACTION_SHUFFLE, appWidgetId)
            bindAction(context, views, R.id.button_favorite, ACTION_FAVORITE, appWidgetId)
            compactWidgetIds.remove(appWidgetId)
        }

        cachedViews[appWidgetId] = views
        manager.updateAppWidget(appWidgetId, views)

        // Flip the wave animation to "playing" or "settling" to match reality.
        // Both calls are cheap no-ops if the engine is already in that state.
        if (isPlaying) {
            WaveAnimationService.startPlaying(context)
        } else {
            WaveAnimationService.triggerSettle(context)
        }
    }

    /**
     * Called ~8x/second by [WaveAnimationService] while the wave is animating.
     * Patches only the wave ImageView on the cached RemoteViews for each
     * placed widget instance, rather than rebuilding everything from scratch.
     */
    /** Call when a widget instance is removed from the home screen, to release its cached views. */
    fun forgetWidget(appWidgetId: Int) {
        cachedViews.remove(appWidgetId)
        compactWidgetIds.remove(appWidgetId)
    }

    fun updateWaveFrame(context: Context, bitmap: Bitmap) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, BubbleMediaWidgetProvider::class.java))
        ids.forEach { id ->
            if (id in compactWidgetIds) return@forEach // compact layout has no wave ImageView
            val views = cachedViews[id] ?: return@forEach
            views.setImageViewBitmap(R.id.image_wave, bitmap)
            manager.updateAppWidget(id, views)
        }
    }

    private fun bindAction(
        context: Context,
        views: RemoteViews,
        viewId: Int,
        action: String,
        appWidgetId: Int
    ) {
        val intent = Intent(context, BubbleMediaWidgetProvider::class.java).apply {
            this.action = action
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }
        val pendingIntent = android.app.PendingIntent.getBroadcast(
            context,
            // unique request code per (widget, action) pair so intents don't collide
            appWidgetId * 10 + action.hashCode() % 10,
            intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(viewId, pendingIntent)
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = TimeUnit.MILLISECONDS.toSeconds(ms)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    private fun roundCorners(bitmap: Bitmap, radiusPx: Float): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val rect = RectF(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat())
        canvas.drawRoundRect(rect, radiusPx, radiusPx, paint)
        return output
    }
}
