package com.bubblewidgets.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect

object BackgroundArtProcessor {

    /**
     * Produces a softly blurred + lightly darkened version of the album art to
     * sit behind the whole widget, like the reference design. Widgets can't use
     * real-time blur (RenderEffect/RenderScript aren't available inside
     * RemoteViews), so this uses a cheap downscale-then-upscale trick: shrinking
     * the image destroys fine detail, and scaling it back up with bilinear
     * filtering reads as a soft blur. Kept light (4x, not 16x) so the art stays
     * recognizable rather than turning to mush, matching the crisper reference
     * look; text legibility comes from [overlay_scrim_and_border]'s bottom
     * gradient rather than a flat scrim here.
     */
    fun process(source: Bitmap, targetWidth: Int = 480, targetHeight: Int = 320): Bitmap {
        val cropped = centerCrop(source, targetWidth, targetHeight)

        val tinyW = (targetWidth / 4).coerceAtLeast(24)
        val tinyH = (targetHeight / 4).coerceAtLeast(24)
        val shrunk = Bitmap.createScaledBitmap(cropped, tinyW, tinyH, true)
        val blurred = Bitmap.createScaledBitmap(shrunk, targetWidth, targetHeight, true)

        val output = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawBitmap(blurred, 0f, 0f, null)

        // Light overall darkening only -- the bulk of the legibility work is
        // done by the bottom-heavy gradient in overlay_scrim_and_border.
        val scrim = Paint()
        scrim.color = 0x33000000 // ~20% black
        canvas.drawRect(0f, 0f, targetWidth.toFloat(), targetHeight.toFloat(), scrim)

        return output
    }

    private fun centerCrop(source: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        val targetRatio = targetWidth.toFloat() / targetHeight.toFloat()
        val sourceRatio = source.width.toFloat() / source.height.toFloat()

        val cropRect: Rect = if (sourceRatio > targetRatio) {
            // source is wider than target -> crop left/right
            val newWidth = (source.height * targetRatio).toInt()
            val left = (source.width - newWidth) / 2
            Rect(left, 0, left + newWidth, source.height)
        } else {
            // source is taller than target -> crop top/bottom
            val newHeight = (source.width / targetRatio).toInt()
            val top = (source.height - newHeight) / 2
            Rect(0, top, source.width, top + newHeight)
        }

        val cropped = Bitmap.createBitmap(
            source, cropRect.left, cropRect.top, cropRect.width(), cropRect.height()
        )
        return Bitmap.createScaledBitmap(cropped, targetWidth, targetHeight, true)
    }
}
