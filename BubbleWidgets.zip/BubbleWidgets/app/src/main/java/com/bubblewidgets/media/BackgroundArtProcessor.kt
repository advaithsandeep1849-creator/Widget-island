package com.bubblewidgets.media

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect

object BackgroundArtProcessor {

    /**
     * Produces a blurred + darkened version of the album art to sit behind the
     * whole widget, like the reference design. Widgets can't use real-time blur
     * (RenderEffect/RenderScript aren't available inside RemoteViews), so this
     * uses a cheap downscale-then-upscale trick: shrinking the image destroys
     * fine detail, and scaling it back up with bilinear filtering reads as a
     * soft blur. It's not as smooth as a real gaussian blur, but it's fast and
     * has zero extra dependencies.
     */
    fun process(source: Bitmap, targetWidth: Int = 480, targetHeight: Int = 320): Bitmap {
        val cropped = centerCrop(source, targetWidth, targetHeight)

        val tinyW = (targetWidth / 16).coerceAtLeast(6)
        val tinyH = (targetHeight / 16).coerceAtLeast(6)
        val shrunk = Bitmap.createScaledBitmap(cropped, tinyW, tinyH, true)
        val blurred = Bitmap.createScaledBitmap(shrunk, targetWidth, targetHeight, true)

        val output = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawBitmap(blurred, 0f, 0f, null)

        // Dark scrim so white text/icons stay legible over any artwork.
        val scrim = Paint()
        scrim.color = 0xB3000000.toInt() // ~70% black
        canvas.drawRect(0f, 0f, targetWidth.toFloat(), targetHeight.toFloat(), scrim)

        return output
    }

    private fun centerCrop(source: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        val targetRatio = targetWidth.toFloat() / targetHeight.toFloat()
        val sourceRatio = source.width.toFloat() / source.height.toFloat()

        val cropRect: Rect = if (sourceRatio > targetRatio) {
            // source is wider than target -> crop left/right
            val newWidth = (source.height * targetRatio).toInt()
            val left = (source.width - newWidth) / 2
            Rect(left, 0, left + newWidth, source.height)
        } else {
            // source is taller than target -> crop top/bottom
            val newHeight = (source.width / targetRatio).toInt()
            val top = (source.height - newHeight) / 2
            Rect(0, top, source.width, top + newHeight)
        }

        val cropped = Bitmap.createBitmap(
            source, cropRect.left, cropRect.top, cropRect.width(), cropRect.height()
        )
        return Bitmap.createScaledBitmap(cropped, targetWidth, targetHeight, true)
    }
}
