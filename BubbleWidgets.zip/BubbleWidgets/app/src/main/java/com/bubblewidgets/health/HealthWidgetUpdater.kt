package com.bubblewidgets.health

import android.appwidget.AppWidgetManager
import android.content.Context
import android.widget.RemoteViews
import com.bubblewidgets.R
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object HealthWidgetUpdater {

    fun updateAppWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int, snapshot: HealthSnapshot) {
        val views = RemoteViews(context.packageName, R.layout.widget_health_player)

        val dateFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())
        views.setTextViewText(R.id.text_date, dateFormatter.format(LocalDate.now()).uppercase())

        views.setTextViewText(R.id.text_steps_value, "%,d".format(snapshot.steps))
        views.setTextViewText(R.id.text_steps_goal, "/ %,d".format(snapshot.stepsGoal))

        views.setTextViewText(R.id.text_calories_value, snapshot.activeCalories.toString())
        views.setTextViewText(R.id.text_calories_goal, "/ ${snapshot.caloriesGoal}")

        views.setTextViewText(R.id.text_active_value, snapshot.activeMinutes.toString())
        views.setTextViewText(R.id.text_active_goal, "/ ${snapshot.activeMinutesGoal} mins")

        val sleepHours = snapshot.sleepMinutes / 60
        val sleepMins = snapshot.sleepMinutes % 60
        views.setTextViewText(R.id.text_sleep_value, "${sleepHours}h ${sleepMins}m")
        views.setTextViewText(R.id.text_sleep_goal, "/ ${snapshot.sleepGoalMinutes / 60}h")

        val rings = RingsGenerator.generate(
            listOf(
                // outer to inner, matching the reference image
                RingsGenerator.Ring(fraction(snapshot.sleepMinutes, snapshot.sleepGoalMinutes), 0xFFB07CFF.toInt()),
                RingsGenerator.Ring(fraction(snapshot.activeMinutes, snapshot.activeMinutesGoal), 0xFFFFC44D.toInt()),
                RingsGenerator.Ring(fraction(snapshot.activeCalories, snapshot.caloriesGoal), 0xFF4CD97B.toInt()),
                RingsGenerator.Ring(fraction(snapshot.steps, snapshot.stepsGoal), 0xFF3BC9FF.toInt()),
            )
        )
        views.setImageViewBitmap(R.id.image_rings, rings)

        manager.updateAppWidget(appWidgetId, views)
    }

    private fun fraction(value: Long, goal: Long): Float {
        if (goal <= 0) return 0f
        return (value.toFloat() / goal.toFloat()).coerceIn(0f, 1f)
    }
}
