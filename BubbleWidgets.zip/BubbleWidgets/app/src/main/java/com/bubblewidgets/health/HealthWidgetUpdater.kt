package com.bubblewidgets.health

import android.appwidget.AppWidgetManager
import android.content.Context
import android.widget.RemoteViews
import com.bubblewidgets.R
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object HealthWidgetUpdater {

    /**
     * Three hand-tuned size buckets, same reasoning as the music widget:
     * fixed dp layouts per size range rather than one layout trying to
     * scale continuously. COMPACT is a small square (rings only), MEDIUM is
     * a shorter/narrower shape (smaller rings + compact metrics), FULL is
     * the original design (rings + date + full legend).
     */
    private enum class Bucket { COMPACT, MEDIUM, FULL }

    private const val COMPACT_WIDTH_THRESHOLD_DP = 180
    private const val FULL_HEIGHT_THRESHOLD_DP = 260

    private fun determineBucket(manager: AppWidgetManager, appWidgetId: Int): Bucket {
        val options = manager.getAppWidgetOptions(appWidgetId)
        val width = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            ?.takeIf { it > 0 }
            ?: options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0) ?: 0
        val height = options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            ?.takeIf { it > 0 }
            ?: options?.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0) ?: 0

        if (width == 0) return Bucket.MEDIUM // no size reported yet (initial placement) -- reasonable middle default
        return when {
            width < COMPACT_WIDTH_THRESHOLD_DP -> Bucket.COMPACT
            height >= FULL_HEIGHT_THRESHOLD_DP -> Bucket.FULL
            else -> Bucket.MEDIUM
        }
    }

    private fun layoutFor(bucket: Bucket): Int = when (bucket) {
        Bucket.COMPACT -> R.layout.widget_health_player_compact
        Bucket.MEDIUM -> R.layout.widget_health_player_medium
        Bucket.FULL -> R.layout.widget_health_player
    }

    fun updateAppWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int, snapshot: HealthSnapshot) {
        val bucket = determineBucket(manager, appWidgetId)
        val views = RemoteViews(context.packageName, layoutFor(bucket))

        val rings = RingsGenerator.generate(
            listOf(
                // outer to inner, matching the reference image
                RingsGenerator.Ring(fraction(snapshot.sleepMinutes, snapshot.sleepGoalMinutes), 0xFFB07CFF.toInt()),
                RingsGenerator.Ring(fraction(snapshot.activeMinutes, snapshot.activeMinutesGoal), 0xFFFFC44D.toInt()),
                RingsGenerator.Ring(fraction(snapshot.activeCalories, snapshot.caloriesGoal), 0xFF4CD97B.toInt()),
                RingsGenerator.Ring(fraction(snapshot.steps, snapshot.stepsGoal), 0xFF3BC9FF.toInt()),
            )
        )

        if (bucket == Bucket.COMPACT) {
            views.setImageViewBitmap(R.id.image_rings_compact, rings)
        } else {
            // MEDIUM and FULL share the same view ID scheme (image_rings,
            // text_steps_value, etc.) even though MEDIUM doesn't have every
            // view FULL does (goal labels, the date/title) -- RemoteViews
            // silently no-ops any action whose target id isn't present in
            // the currently inflated layout, so this one block safely
            // covers both.
            views.setImageViewBitmap(R.id.image_rings, rings)

            val dateFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())
            views.setTextViewText(R.id.text_date, dateFormatter.format(LocalDate.now()).uppercase())

            views.setTextViewText(R.id.text_steps_value, "%,d".format(snapshot.steps))
            views.setTextViewText(R.id.text_steps_goal, "/ %,d".format(snapshot.stepsGoal))

            views.setTextViewText(R.id.text_calories_value, snapshot.activeCalories.toString())
            views.setTextViewText(R.id.text_calories_goal, "/ ${snapshot.caloriesGoal}")

            views.setTextViewText(R.id.text_active_value, snapshot.activeMinutes.toString())
            views.setTextViewText(R.id.text_active_goal, "/ ${snapshot.activeMinutesGoal} mins")

            val sleepHours = snapshot.sleepMinutes / 60
            val sleepMins = snapshot.sleepMinutes % 60
            views.setTextViewText(R.id.text_sleep_value, "${sleepHours}h ${sleepMins}m")
            views.setTextViewText(R.id.text_sleep_goal, "/ ${snapshot.sleepGoalMinutes / 60}h")
        }

        manager.updateAppWidget(appWidgetId, views)
    }

    private fun fraction(value: Long, goal: Long): Float {
        if (goal <= 0) return 0f
        return (value.toFloat() / goal.toFloat()).coerceIn(0f, 1f)
    }
}
