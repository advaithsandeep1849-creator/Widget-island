package com.bubblewidgets.ui.theme

import androidx.compose.ui.graphics.Color

// Deep space background -- near-black with a faint blue/purple cast, matching
// both reference screens rather than a flat pure black.
val SpaceBlack = Color(0xFF05060C)
val SpaceNavy = Color(0xFF0B0E1D)
val SpaceIndigo = Color(0xFF141A33)

// "Bubble" wordmark gradient: cool white fading to sky blue.
val WordmarkStart = Color(0xFFFFFFFF)
val WordmarkEnd = Color(0xFF6EA8FF)

val TextPrimary = Color(0xFFF2F4FF)
val TextSecondary = Color(0xFFA7ADC7)
val TextMuted = Color(0xFF6D7290)

// Frosted glass card material, echoing the widgets' own glassmorphism.
val GlassFill = Color(0x1AFFFFFF)
val GlassRim = Color(0x33FFFFFF)
val GlassSheen = Color(0x14FFFFFF)

// Per-category accent colors, used for each card's icon glow and subtle tint.
val AccentMedia = Color(0xFFFF5CA8)
val AccentHealth = Color(0xFF3CE7B0)
val AccentClock = Color(0xFFFFC44D)
val AccentWeather = Color(0xFF5CC8FF)
val AccentTools = Color(0xFFB07CFF)
val AccentAesthetic = Color(0xFFFF8A5C)
